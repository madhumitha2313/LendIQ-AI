"""
LendIQ — model training script.

Trains the XGBoost loan-approval classifier and persists it to
model/best_xgb.pkl. If a real Kaggle "Loan Prediction" CSV is present
at data/loan.csv it is used; otherwise a realistic synthetic dataset
(consistent with that schema) is generated so the pipeline is fully
reproducible offline.

Run:  python train_model.py
"""
from __future__ import annotations

import os
import pickle

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix,
)

from pipeline import engineer, clean_row, FEATURE_ORDER

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(HERE, "model", "best_xgb.pkl")
DATA_PATH = os.path.join(HERE, "data", "loan.csv")
RNG = np.random.default_rng(42)

# Population stats (shared with the JS engine) for a logistic ground truth.
STATS = {
    "credit_history": (0.842, 0.365), "emi_to_income": (0.062, 0.045),
    "loan_to_income": (1.70, 1.05), "log_total_income": (8.70, 0.52),
    "dependents": (0.76, 1.01), "graduate": (0.781, 0.414),
    "married": (0.651, 0.477), "self_employed": (0.141, 0.348),
    "area_score": (1.04, 0.79), "male": (0.814, 0.389),
}
TRUE_W = {
    "credit_history": 2.35, "emi_to_income": -0.78, "loan_to_income": -0.52,
    "log_total_income": 0.46, "dependents": -0.18, "graduate": 0.27,
    "married": 0.21, "self_employed": -0.16, "area_score": 0.24, "male": 0.06,
}
INTERCEPT = 0.34


def _pick(opts):
    return opts[RNG.integers(0, len(opts))]


def synth_raw(n: int) -> list[dict]:
    rows = []
    for _ in range(n):
        rows.append({
            "Loan_ID": f"LP{RNG.integers(100000, 999999)}",
            "Gender": _pick(["Male", "Male", "Female"]),
            "Married": _pick(["Yes", "Yes", "No"]),
            "Dependents": _pick(["0", "0", "1", "2", "3+"]),
            "Education": _pick(["Graduate", "Graduate", "Graduate", "Not Graduate"]),
            "Self_Employed": _pick(["No", "No", "No", "Yes"]),
            "ApplicantIncome": int(np.clip(4500 + RNG.normal() * 2600, 1200, 22000)),
            "CoapplicantIncome": int(_pick([0, 0, int(np.clip(1500 + RNG.normal() * 1400, 0, 9000))])),
            "LoanAmount": int(np.clip(135 + RNG.normal() * 70, 30, 600)),
            "Loan_Amount_Term": int(_pick([360, 360, 360, 180, 240, 120])),
            "Credit_History": 1 if RNG.random() < 0.84 else 0,
            "Property_Area": _pick(["Urban", "Semiurban", "Semiurban", "Rural"]),
        })
    return rows


def build_dataset():
    if os.path.exists(DATA_PATH):
        print(f"→ Using real dataset at {DATA_PATH}")
        df = pd.read_csv(DATA_PATH)
        raw = df.to_dict("records")
        feats = pd.DataFrame([engineer(clean_row(r))[0] for r in raw])[FEATURE_ORDER]
        if "Loan_Status" in df.columns:
            y = df["Loan_Status"].map(lambda v: 1 if str(v).strip().upper() in ("Y", "1", "YES") else 0)
            return feats, y.values
        # fall through to synthetic labels if no target column
        raw_rows = raw
    else:
        print("→ No real dataset found; generating synthetic data (schema-consistent).")
        raw_rows = synth_raw(3000)

    feats = pd.DataFrame([engineer(clean_row(r))[0] for r in raw_rows])[FEATURE_ORDER]

    # Logistic ground truth + label noise → realistic, learnable target.
    logit = np.full(len(feats), INTERCEPT)
    for k in FEATURE_ORDER:
        mean, std = STATS[k]
        logit += TRUE_W[k] * ((feats[k].values - mean) / std)
    prob = 1 / (1 + np.exp(-logit))
    y = (RNG.random(len(feats)) < prob).astype(int)
    return feats, y


def main():
    try:
        from xgboost import XGBClassifier
    except ImportError:
        raise SystemExit("xgboost is required. Install with: pip install -r requirements.txt")

    X, y = build_dataset()
    print(f"Dataset: {len(X)} rows · approval rate {y.mean():.2%}")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    grid = {
        "n_estimators": [200, 350],
        "max_depth": [3, 4],
        "learning_rate": [0.05, 0.1],
        "subsample": [0.9],
        "colsample_bytree": [0.9],
    }
    base = XGBClassifier(
        objective="binary:logistic", eval_metric="logloss",
        use_label_encoder=False, random_state=42, n_jobs=-1,
    )
    print("Running GridSearchCV (this trains several XGBoost models)…")
    search = GridSearchCV(base, grid, scoring="accuracy", cv=4, n_jobs=-1, verbose=0)
    search.fit(X_train, y_train)
    model = search.best_estimator_
    print(f"Best params: {search.best_params_}")

    pred = model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1]
    print("\n──────── Evaluation ────────")
    print(f"Accuracy : {accuracy_score(y_test, pred):.4f}")
    print(f"Precision: {precision_score(y_test, pred):.4f}")
    print(f"Recall   : {recall_score(y_test, pred):.4f}")
    print(f"F1 Score : {f1_score(y_test, pred):.4f}")
    print(f"ROC-AUC  : {roc_auc_score(y_test, proba):.4f}")
    print(f"Confusion matrix:\n{confusion_matrix(y_test, pred)}")

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump({"model": model, "feature_order": FEATURE_ORDER}, f)
    print(f"\n✓ Saved model → {MODEL_PATH}")


if __name__ == "__main__":
    main()
