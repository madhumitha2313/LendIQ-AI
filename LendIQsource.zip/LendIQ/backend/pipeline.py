"""
LendIQ — shared feature pipeline.

Cleaning, missing-value treatment, feature engineering and categorical
encoding. This mirrors the in-browser preprocessing (preprocessing.js)
exactly so the FastAPI/XGBoost service and the JS Edge Engine agree on
the feature space.
"""
from __future__ import annotations

import math
from typing import Dict, List

import numpy as np
import pandas as pd

# Model-ready feature order (must match scoringEngine.js).
FEATURE_ORDER: List[str] = [
    "credit_history",
    "emi_to_income",
    "loan_to_income",
    "log_total_income",
    "dependents",
    "graduate",
    "married",
    "self_employed",
    "area_score",
    "male",
]

FEATURE_LABELS: Dict[str, str] = {
    "credit_history": "Credit History",
    "emi_to_income": "EMI-to-Income Ratio",
    "loan_to_income": "Loan-to-Income Ratio",
    "log_total_income": "Total Income",
    "dependents": "Dependents",
    "graduate": "Education",
    "married": "Marital Status",
    "self_employed": "Employment Type",
    "area_score": "Property Area",
    "male": "Applicant Gender",
}

DEFAULTS = {
    "Gender": "Male",
    "Married": "Yes",
    "Dependents": "0",
    "Education": "Graduate",
    "Self_Employed": "No",
    "ApplicantIncome": 3812.0,
    "CoapplicantIncome": 1188.0,
    "LoanAmount": 128.0,
    "Loan_Amount_Term": 360.0,
    "Credit_History": 1,
    "Property_Area": "Semiurban",
}

_TRUTHY = {"yes", "y", "true", "1", "male", "graduate", "good"}


def _truthy(v) -> int:
    return 1 if str(v).strip().lower() in _TRUTHY else 0


def _num(v, fallback: float) -> float:
    try:
        return float(str(v).replace(",", "").strip())
    except (ValueError, TypeError):
        return float(fallback)


def clean_row(raw: dict) -> dict:
    """Coerce a single raw applicant record into a clean, complete record."""
    def get(k):
        v = raw.get(k)
        return None if v in (None, "", "nan") else v

    dep_raw = get("Dependents")
    dependents = _num(str(dep_raw).replace("+", ""), DEFAULTS["Dependents"]) if dep_raw is not None \
        else _num(DEFAULTS["Dependents"], 0)

    credit_raw = get("Credit_History")
    if credit_raw is None:
        credit = DEFAULTS["Credit_History"]
    else:
        s = str(credit_raw).strip().lower()
        try:
            # Handles 1, 1.0, "1", "1.0", 0, 0.0 …
            credit = 1 if float(s) >= 0.5 else 0
        except ValueError:
            credit = 1 if s in {"yes", "y", "true", "good"} else 0

    return {
        "Loan_ID": get("Loan_ID") or "LP-API",
        "Gender": get("Gender") or DEFAULTS["Gender"],
        "Married": get("Married") or DEFAULTS["Married"],
        "Dependents": dependents,
        "Education": get("Education") or DEFAULTS["Education"],
        "Self_Employed": get("Self_Employed") or DEFAULTS["Self_Employed"],
        "ApplicantIncome": _num(get("ApplicantIncome"), DEFAULTS["ApplicantIncome"]),
        "CoapplicantIncome": _num(get("CoapplicantIncome"), DEFAULTS["CoapplicantIncome"]),
        "LoanAmount": _num(get("LoanAmount"), DEFAULTS["LoanAmount"]),
        "Loan_Amount_Term": _num(get("Loan_Amount_Term"), DEFAULTS["Loan_Amount_Term"]),
        "Credit_History": credit,
        "Property_Area": get("Property_Area") or DEFAULTS["Property_Area"],
    }


def engineer(clean: dict):
    """Feature engineering → (feature dict, derived metrics dict)."""
    total_income = max(clean["ApplicantIncome"] + clean["CoapplicantIncome"], 1.0)
    principal = clean["LoanAmount"] * 1000.0
    term = max(clean["Loan_Amount_Term"], 1.0)
    emi = principal / term
    emi_to_income = emi / total_income
    loan_to_income = principal / (total_income * 12.0)

    area = str(clean["Property_Area"]).strip().lower()
    area_score = 2 if area.startswith("semi") else 1 if area.startswith("urban") else 0

    features = {
        "credit_history": float(clean["Credit_History"]),
        "emi_to_income": emi_to_income,
        "loan_to_income": loan_to_income,
        "log_total_income": math.log(total_income),
        "dependents": float(clean["Dependents"]),
        "graduate": float(_truthy(clean["Education"])),
        "married": float(_truthy(clean["Married"])),
        "self_employed": float(_truthy(clean["Self_Employed"])),
        "area_score": float(area_score),
        "male": float(_truthy(clean["Gender"])),
    }
    derived = {
        "totalIncome": round(total_income),
        "emi": round(emi),
        "emiToIncome": round(emi_to_income * 100, 1),
        "loanToIncome": round(loan_to_income, 2),
    }
    return features, derived


def to_feature_frame(raw_rows: List[dict]) -> pd.DataFrame:
    """Raw rows → model-ready DataFrame in canonical column order."""
    feats = [engineer(clean_row(r))[0] for r in raw_rows]
    return pd.DataFrame(feats)[FEATURE_ORDER]


def risk_band(approval_prob: float):
    score = round((1 - approval_prob) * 100, 1)
    level = "LOW" if score < 33 else "MEDIUM" if score < 66 else "HIGH"
    return score, level
