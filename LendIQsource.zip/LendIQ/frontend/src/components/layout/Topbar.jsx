import { useNavigate } from 'react-router-dom'
import { Menu, Search, Bell, Sun, Moon, Sparkles } from 'lucide-react'
import { useTheme } from '../../context/ThemeContext'
import { useAuth } from '../../context/AuthContext'

export default function Topbar({ onMenu }) {
  const { theme, toggle } = useTheme()
  const { user, mode } = useAuth()
  const navigate = useNavigate()
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'

  return (
    <header className="topbar">
      <div className="flex items-center gap-sm">
        <button className="icon-btn hamburger" onClick={onMenu} aria-label="Menu">
          <Menu size={18} />
        </button>
        <div>
          <div style={{ fontSize: 15, fontWeight: 700 }}>
            {greeting}, {user?.name?.split(' ')[0] || 'there'} 👋
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-faint)' }}>
            {mode === 'firebase' ? 'Firebase session' : 'Local demo session'} · Model XGBoost · 88.62% accuracy
          </div>
        </div>
      </div>

      <div className="topbar-search">
        <Search size={16} />
        <input placeholder="Search applicants, decisions, reports…" onKeyDown={(e) => e.key === 'Enter' && navigate('/history')} />
      </div>

      <div className="flex items-center gap-sm">
        <button className="btn btn-teal btn-sm" onClick={() => navigate('/manual')}>
          <Sparkles size={15} /> New Prediction
        </button>
        <button className="icon-btn" onClick={toggle} aria-label="Toggle theme">
          {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
        </button>
        <button className="icon-btn" aria-label="Notifications" onClick={() => navigate('/history')}>
          <Bell size={18} />
        </button>
      </div>
    </header>
  )
}
