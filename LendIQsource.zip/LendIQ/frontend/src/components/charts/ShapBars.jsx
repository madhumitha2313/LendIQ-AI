// Diverging SHAP contribution bars (local explanation).
export default function ShapBars({ contributions = [], max = 8 }) {
  const items = [...contributions]
    .sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution))
    .slice(0, max)
  const peak = Math.max(...items.map((c) => Math.abs(c.contribution)), 0.001)

  return (
    <div>
      {items.map((c) => {
        const pct = (Math.abs(c.contribution) / peak) * 48 // up to 48% of half-width
        const positive = c.contribution >= 0
        return (
          <div className="shap-row" key={c.key || c.label}>
            <div className="name" title={c.label}>{c.label}</div>
            <div className="track">
              <div className="center-line" />
              <div
                className="shap-bar-seg"
                style={{
                  position: 'absolute',
                  left: positive ? '50%' : `${50 - pct}%`,
                  width: `${pct}%`,
                  background: positive
                    ? 'linear-gradient(90deg, #16a34a, #22c55e)'
                    : 'linear-gradient(90deg, #ef4444, #f87171)',
                }}
              />
            </div>
            <div className="val" style={{ color: positive ? '#4ade80' : '#f87171' }}>
              {positive ? '+' : ''}{c.contribution.toFixed(3)}
            </div>
          </div>
        )
      })}
    </div>
  )
}
