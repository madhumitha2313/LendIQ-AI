// Animated semicircular risk gauge (0–100, LOW/MEDIUM/HIGH).
import { useEffect, useState } from 'react'

export default function RiskGauge({ score = 0, level = 'LOW', color = '#22c55e', size = 220 }) {
  const [animScore, setAnimScore] = useState(0)
  useEffect(() => {
    const id = setTimeout(() => setAnimScore(score), 120)
    return () => clearTimeout(id)
  }, [score])

  const angle = -90 + (animScore / 100) * 180
  const cx = 100, cy = 100, r = 78
  // arc path helper
  const polar = (deg) => {
    const rad = ((deg - 180) * Math.PI) / 180
    return [cx + r * Math.cos(rad), cy + r * Math.sin(rad)]
  }
  const seg = (from, to, stroke) => {
    const [x1, y1] = polar(from)
    const [x2, y2] = polar(to)
    const large = to - from > 180 ? 1 : 0
    return <path d={`M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`} stroke={stroke} strokeWidth="14" fill="none" strokeLinecap="round" />
  }

  return (
    <div className="gauge-wrap">
      <svg width={size} height={size * 0.62} viewBox="0 0 200 120">
        {/* tracks */}
        {seg(0, 60, 'rgba(34,197,94,0.25)')}
        {seg(60, 120, 'rgba(245,158,11,0.25)')}
        {seg(120, 180, 'rgba(239,68,68,0.25)')}
        {/* active fill up to score */}
        {seg(0, Math.max(2, (animScore / 100) * 180), color)}
        {/* needle */}
        <g className="gauge-needle" style={{ transform: `rotate(${angle}deg)` }}>
          <line x1="100" y1="100" x2="100" y2="34" stroke="#fff" strokeWidth="3" strokeLinecap="round" />
          <circle cx="100" cy="100" r="7" fill="#fff" />
          <circle cx="100" cy="100" r="3.5" fill={color} />
        </g>
      </svg>
      <div style={{ textAlign: 'center', marginTop: -8 }}>
        <div className="gauge-value" style={{ color }}>{score}</div>
        <span className="badge" style={{ background: `${color}22`, color, borderColor: `${color}55` }}>
          {level} RISK
        </span>
      </div>
    </div>
  )
}
