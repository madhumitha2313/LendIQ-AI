export default function Footer() {
  return (
    <footer
      style={{
        padding: '20px 30px',
        borderTop: '1px solid var(--stroke)',
        display: 'flex',
        flexWrap: 'wrap',
        gap: 8,
        justifyContent: 'space-between',
        alignItems: 'center',
        color: 'var(--text-faint)',
        fontSize: 12.5,
      }}
    >
      <div>
        <strong style={{ color: 'var(--text-dim)' }}>LendIQ</strong> · Version 1.0
      </div>
      <div>Powered by XGBoost + SHAP + Firebase</div>
      <div>© 2026 LendIQ. All rights reserved.</div>
    </footer>
  )
}
