# Deploying LendIQ to a public URL

LendIQ ships two deployables:

- **Frontend** (React static site) — works on its own using the in-browser
  Edge Engine, so you can deploy it with **no backend at all**.
- **Backend** (FastAPI + XGBoost + SHAP) — optional; connect it for real
  model predictions.

Recommended (free, permanent): **Vercel for the frontend + Render for the
backend.** Fastest possible link: **Netlify drag-and-drop** (below).

---

## ⚡ Fastest clickable link (no CLI) — Netlify Drop

1. Build the static site:
   ```bash
   cd frontend && npm install && npm run build
   ```
2. Go to **https://app.netlify.com/drop** and drag the `frontend/dist`
   folder onto the page.
3. You get a public URL in ~10 seconds. It runs fully on the Edge Engine.

---

## 1) Frontend → Vercel (permanent, GitHub-connected)

1. Push this repo to GitHub (already on your branch).
2. **vercel.com → New Project → Import** this repo.
3. Vercel reads `vercel.json` automatically:
   - Build: `cd frontend && npm install && npm run build`
   - Output: `frontend/dist`
   - SPA rewrites are configured.
4. (Optional) To use the real backend, add Environment Variables:
   | Key | Value |
   |-----|-------|
   | `VITE_API_BASE_URL` | your Render API URL, e.g. `https://lendiq-api.onrender.com` |
   | `VITE_API_KEY` | the key Render generated (see below) |
   | `VITE_FIREBASE_*` | optional, for real auth + Firestore history |
5. Deploy → you get `https://<project>.vercel.app`.

> Netlify works identically via the included `netlify.toml` (base `frontend`).

---

## 2) Backend → Render (FastAPI · XGBoost · SHAP)

1. **render.com → New → Blueprint** → select this repo.
2. Render reads `render.yaml` and builds `backend/Dockerfile`
   (the model is trained during the image build, so it starts instantly).
3. After deploy:
   - Copy the service URL, e.g. `https://lendiq-api.onrender.com`
   - In the service's **Environment** tab, reveal the generated
     `LENDIQ_API_KEY` value.
4. Put those two values into the frontend env (step 1.4) and redeploy the
   frontend. Decisions will now read **“Engine: FastAPI Service.”**
5. Lock down CORS: set `LENDIQ_CORS_ORIGINS` to your exact frontend origin.

Any container host works too (Railway, Fly.io, Cloud Run) — they all use
`backend/Dockerfile`.

---

## 3) Firebase (optional — real auth + history)

1. Create a Firebase project, enable **Email/Password** auth and **Firestore**.
2. Add the web app config values as `VITE_FIREBASE_*` env vars on the frontend.
3. Suggested Firestore rule (owner-scoped):
   ```
   match /predictions/{id} {
     allow read, write: if request.auth != null
       && request.resource.data.uid == request.auth.uid;
   }
   ```

Without Firebase, LendIQ uses local/demo auth + localStorage history — the
app stays fully functional.

---

## Local full stack (one command)

```bash
npm run setup    # deps + train model + write frontend/.env
npm run dev      # React :5173  +  FastAPI :8000
```
