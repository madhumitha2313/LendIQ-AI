// ============================================================
// historyService.js
// Persists every prediction with user ownership. Uses Firestore
// when Firebase is configured, otherwise a per-user localStorage
// store. Same async API either way: save / list / remove / clear.
// ============================================================
import { db, firebaseEnabled } from '../firebase/config'
import {
  collection,
  addDoc,
  query,
  where,
  orderBy,
  getDocs,
  deleteDoc,
  doc,
  serverTimestamp,
} from 'firebase/firestore'

const COL = 'predictions'
const lsKey = (uid) => `lendiq:history:${uid}`

/** Compress a full prediction into a storable history record. */
export function toRecord(pred, uid, source = 'manual') {
  return {
    uid,
    source,
    applicantId: pred.id,
    prediction: pred.prediction,
    approved: pred.approved,
    confidence: pred.confidence,
    approvalProbability: pred.approvalProbability,
    riskScore: pred.riskScore,
    riskLevel: pred.riskLevel,
    reason:
      (pred.approved ? pred.topPositive?.[0]?.label : pred.topNegative?.[0]?.label) || '—',
    timestamp: pred.timestamp || new Date().toISOString(),
    snapshot: {
      input: pred.input,
      contributions: pred.contributions,
      derived: pred.derived,
      model: pred.model,
      engine: pred.engine,
    },
  }
}

/* ----------------------- localStorage backend ----------------------- */
const lsRead = (uid) => {
  try { return JSON.parse(localStorage.getItem(lsKey(uid)) || '[]') } catch { return [] }
}
const lsWrite = (uid, list) => localStorage.setItem(lsKey(uid), JSON.stringify(list))

/* ----------------------------- public API ----------------------------- */
export async function savePrediction(pred, uid, source = 'manual') {
  const record = toRecord(pred, uid, source)
  if (firebaseEnabled && db) {
    const ref = await addDoc(collection(db, COL), { ...record, createdAt: serverTimestamp() })
    return { id: ref.id, ...record }
  }
  const list = lsRead(uid)
  const item = { id: `loc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, ...record }
  list.unshift(item)
  lsWrite(uid, list)
  return item
}

/** Save many predictions (batch). */
export async function savePredictions(preds, uid, source = 'batch') {
  const out = []
  for (const p of preds) out.push(await savePrediction(p, uid, source))
  return out
}

export async function listPredictions(uid) {
  if (firebaseEnabled && db) {
    const q = query(collection(db, COL), where('uid', '==', uid), orderBy('createdAt', 'desc'))
    const snap = await getDocs(q)
    return snap.docs.map((d) => ({ id: d.id, ...d.data() }))
  }
  return lsRead(uid)
}

export async function deletePrediction(id, uid) {
  if (firebaseEnabled && db) {
    await deleteDoc(doc(db, COL, id))
    return
  }
  lsWrite(uid, lsRead(uid).filter((r) => r.id !== id))
}

export async function clearHistory(uid, ids = null) {
  if (firebaseEnabled && db) {
    const list = await listPredictions(uid)
    const target = ids ? list.filter((r) => ids.includes(r.id)) : list
    await Promise.all(target.map((r) => deleteDoc(doc(db, COL, r.id))))
    return
  }
  if (ids) lsWrite(uid, lsRead(uid).filter((r) => !ids.includes(r.id)))
  else lsWrite(uid, [])
}
