// ============================================================
// recommendationEngine.js  —  "AI Loan Advisor"
// Turns a SHAP-decomposed prediction into a human narrative:
// primary reasons + concrete, prioritised recommended actions.
// ============================================================

const REASON_TEXT = {
  credit_history: {
    neg: 'Weak or missing credit history',
    pos: 'Strong, established credit history',
  },
  emi_to_income: {
    neg: 'High EMI relative to monthly income',
    pos: 'Comfortable EMI-to-income ratio',
  },
  loan_to_income: {
    neg: 'Requested loan is large relative to income',
    pos: 'Loan size is well-supported by income',
  },
  log_total_income: {
    neg: 'Household income is on the lower side',
    pos: 'Healthy household income',
  },
  dependents: { neg: 'Higher number of dependents', pos: 'Low dependent burden' },
  graduate: { neg: 'Non-graduate profile', pos: 'Graduate education profile' },
  married: { neg: 'Single-applicant stability profile', pos: 'Dual-stability marital profile' },
  self_employed: { neg: 'Self-employed income variability', pos: 'Salaried income stability' },
  area_score: { neg: 'Property area with lower approval base rate', pos: 'Property in a favourable area' },
  male: { neg: 'Demographic factor', pos: 'Demographic factor' },
}

const ACTION_LIBRARY = {
  credit_history: [
    'Improve credit history by clearing outstanding dues and avoiding late payments',
    'Maintain at least 6 months of clean repayment records before reapplying',
  ],
  emi_to_income: [
    'Choose a longer loan tenure to reduce the monthly EMI',
    'Reduce the requested loan amount to lower the EMI burden',
  ],
  loan_to_income: [
    'Reduce the requested loan amount',
    'Add a co-applicant with stable income to raise borrowing capacity',
  ],
  log_total_income: [
    'Add a co-applicant with stable income',
    'Provide additional verified income sources',
  ],
  dependents: ['Demonstrate additional repayment capacity to offset dependents'],
  self_employed: ['Provide 2–3 years of audited financials to evidence stable income'],
}

/**
 * Build the AI advisor narrative for a prediction.
 */
export function buildAdvisory(pred) {
  if (pred.approved) {
    const positives = pred.topPositive.map((c) => REASON_TEXT[c.key]?.pos || c.label)
    return {
      tone: 'positive',
      headline: 'This application meets LendIQ approval criteria.',
      reasons: positives.slice(0, 4),
      actions: [
        'Proceed with standard verification and documentation',
        'Offer pre-approved top-up products given the strong profile',
        'Lock the rate to convert this qualified applicant quickly',
      ],
      summary:
        `The applicant qualifies with an approval probability of ${pred.approvalProbability}% ` +
        `and ${pred.riskLevel.toLowerCase()} risk. The decision is driven primarily by ` +
        `${(pred.topPositive[0]?.label || 'a strong financial profile').toLowerCase()}.`,
    }
  }

  // Rejected → surface the strongest negative drivers + remediation.
  const negs = pred.topNegative
  const reasons = negs.map((c) => REASON_TEXT[c.key]?.neg || c.label).slice(0, 4)

  const actions = []
  negs.forEach((c) => {
    ;(ACTION_LIBRARY[c.key] || []).forEach((a) => {
      if (!actions.includes(a)) actions.push(a)
    })
  })
  if (!actions.includes('Add a co-applicant with stable income'))
    actions.push('Add a co-applicant with stable income')
  actions.push('Reapply after improving the financial profile')

  return {
    tone: 'negative',
    headline: 'This application does not currently meet approval criteria.',
    reasons: reasons.length ? reasons : ['Overall financial profile is below threshold'],
    actions: actions.slice(0, 5),
    summary:
      `The application was declined with ${pred.confidence}% confidence and ${pred.riskLevel.toLowerCase()} risk. ` +
      `The main factor is ${(negs[0]?.label || 'the overall profile').toLowerCase()}. ` +
      `Addressing the actions below can materially improve the outcome on reapplication.`,
  }
}

/** One-line reason string for compact tables / history. */
export function shortReason(pred) {
  if (pred.approved) return pred.topPositive[0]?.label || 'Strong profile'
  return pred.topNegative[0]?.label || 'Below threshold'
}
