// ============================================================
// preprocessing.js
// Mirrors the LendIQ training pipeline: cleaning, missing-value
// treatment, feature engineering and categorical encoding.
// The output feature vector is consumed by the scoring engine
// (offline) and is identical in shape to what the FastAPI/XGBoost
// service expects.
// ============================================================

export const RAW_COLUMNS = [
  'Loan_ID',
  'Gender',
  'Married',
  'Dependents',
  'Education',
  'Self_Employed',
  'ApplicantIncome',
  'CoapplicantIncome',
  'LoanAmount',
  'Loan_Amount_Term',
  'Credit_History',
  'Property_Area',
]

// Population statistics from the training data — used for imputation,
// standardisation and (critically) for SHAP base-value computation.
export const STATS = {
  credit_history:  { mean: 0.842, std: 0.365 },
  emi_to_income:   { mean: 0.062, std: 0.045 },
  loan_to_income:  { mean: 1.70,  std: 1.05 },
  log_total_income:{ mean: 8.70,  std: 0.52 },
  dependents:      { mean: 0.76,  std: 1.01 },
  graduate:        { mean: 0.781, std: 0.414 },
  married:         { mean: 0.651, std: 0.477 },
  self_employed:   { mean: 0.141, std: 0.348 },
  area_score:      { mean: 1.04,  std: 0.79 },
  male:            { mean: 0.814, std: 0.389 },
}

// Defaults used when a value is missing (median / mode of the dataset).
const DEFAULTS = {
  Gender: 'Male',
  Married: 'Yes',
  Dependents: '0',
  Education: 'Graduate',
  Self_Employed: 'No',
  ApplicantIncome: 3812,
  CoapplicantIncome: 1188,
  LoanAmount: 128,
  Loan_Amount_Term: 360,
  Credit_History: 1,
  Property_Area: 'Semiurban',
}

const truthy = (v) =>
  ['yes', 'y', 'true', '1', 'male', 'graduate'].includes(String(v).trim().toLowerCase())

const num = (v, fallback) => {
  const n = parseFloat(String(v).replace(/[, ]/g, ''))
  return Number.isFinite(n) ? n : fallback
}

/**
 * Normalise + coerce a single raw applicant row into a clean record.
 */
export function cleanRow(raw = {}) {
  const get = (k) => (raw[k] === undefined || raw[k] === '' || raw[k] === null ? undefined : raw[k])

  const dependentsRaw = get('Dependents')
  const dependents =
    dependentsRaw === undefined ? num(DEFAULTS.Dependents, 0) : num(String(dependentsRaw).replace('+', ''), 0)

  let creditRaw = get('Credit_History')
  let credit_history
  if (creditRaw === undefined) credit_history = DEFAULTS.Credit_History
  else {
    const s = String(creditRaw).trim().toLowerCase()
    credit_history = ['1', 'yes', 'y', 'true', 'good'].includes(s) ? 1 : 0
  }

  return {
    Loan_ID: get('Loan_ID') || `LP-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
    Gender: get('Gender') ?? DEFAULTS.Gender,
    Married: get('Married') ?? DEFAULTS.Married,
    Dependents: dependents,
    Education: get('Education') ?? DEFAULTS.Education,
    Self_Employed: get('Self_Employed') ?? DEFAULTS.Self_Employed,
    ApplicantIncome: num(get('ApplicantIncome'), DEFAULTS.ApplicantIncome),
    CoapplicantIncome: num(get('CoapplicantIncome'), DEFAULTS.CoapplicantIncome),
    LoanAmount: num(get('LoanAmount'), DEFAULTS.LoanAmount),
    Loan_Amount_Term: num(get('Loan_Amount_Term'), DEFAULTS.Loan_Amount_Term),
    Credit_History: credit_history,
    Property_Area: get('Property_Area') ?? DEFAULTS.Property_Area,
  }
}

/**
 * Feature engineering + encoding → the model-ready feature vector.
 * Returns both the engineered values and useful derived metrics.
 */
export function engineerFeatures(clean) {
  const totalIncome = Math.max(clean.ApplicantIncome + clean.CoapplicantIncome, 1)
  const principal = clean.LoanAmount * 1000 // dataset stores amount in thousands
  const term = Math.max(clean.Loan_Amount_Term, 1)
  const emi = principal / term
  const emiToIncome = emi / totalIncome
  const loanToIncome = principal / (totalIncome * 12)

  const area = String(clean.Property_Area).trim().toLowerCase()
  const areaScore = area.startsWith('semi') ? 2 : area.startsWith('urban') ? 1 : 0

  const features = {
    credit_history: clean.Credit_History,
    emi_to_income: emiToIncome,
    loan_to_income: loanToIncome,
    log_total_income: Math.log(totalIncome),
    dependents: clean.Dependents,
    graduate: truthy(clean.Education) ? 1 : 0,
    married: truthy(clean.Married) ? 1 : 0,
    self_employed: truthy(clean.Self_Employed) ? 1 : 0,
    area_score: areaScore,
    male: truthy(clean.Gender) ? 1 : 0,
  }

  return {
    features,
    derived: { totalIncome, emi, emiToIncome, loanToIncome, principal },
  }
}

/** Convenience: raw row → { clean, features, derived }. */
export function preprocess(raw) {
  const clean = cleanRow(raw)
  const { features, derived } = engineerFeatures(clean)
  return { clean, features, derived }
}

/** Validate that an uploaded dataset has the expected columns. */
export function validateColumns(headers = []) {
  const present = headers.map((h) => String(h).trim())
  const lower = present.map((h) => h.toLowerCase())
  const required = ['ApplicantIncome', 'LoanAmount', 'Credit_History']
  const missing = required.filter((r) => !lower.includes(r.toLowerCase()))
  const recognised = RAW_COLUMNS.filter((c) => lower.includes(c.toLowerCase()))
  return { ok: missing.length === 0, missing, recognised }
}
