import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  History as HistoryIcon, Search, Trash2, Eye, FileText, FileDown, FileSpreadsheet,
  Filter, CheckSquare, Square,
} from 'lucide-react'
import { deletePrediction, clearHistory } from '../services/historyService'
import { exportCSV, exportExcel, exportPredictionPDF } from '../services/exportService'
import { scoreApplicant } from '../engine/scoringEngine'
import { usePrediction } from '../context/PredictionContext'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

// Rebuild a full prediction object from a stored history record.
function recordToPrediction(r) {
  if (r.snapshot?.input) {
    const pred = scoreApplicant(r.snapshot.input)
    pred.id = r.applicantId
    pred.timestamp = r.timestamp
    return pred
  }
  return {
    id: r.applicantId, approved: r.approved, prediction: r.prediction, confidence: r.confidence,
    approvalProbability: r.approvalProbability, rejectionProbability: 100 - (r.approvalProbability || 0),
    riskScore: r.riskScore, riskLevel: r.riskLevel, contributions: r.snapshot?.contributions || [],
    topPositive: [], topNegative: [], model: r.snapshot?.model || 'XGBoost', engine: r.snapshot?.engine || '—',
    derived: r.snapshot?.derived || {}, input: r.snapshot?.input || {}, timestamp: r.timestamp,
  }
}

export default function History() {
  const { history, refreshHistory } = usePrediction()
  const { user } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()
  const { setLastPrediction } = usePrediction()

  const [q, setQ] = useState('')
  const [decision, setDecision] = useState('all')
  const [risk, setRisk] = useState('all')
  const [selected, setSelected] = useState(new Set())

  const filtered = useMemo(() => {
    return history.filter((h) => {
      if (decision !== 'all' && (decision === 'approved') !== !!h.approved) return false
      if (risk !== 'all' && h.riskLevel !== risk) return false
      if (q) {
        const blob = `${h.applicantId} ${h.reason} ${h.prediction}`.toLowerCase()
        if (!blob.includes(q.toLowerCase())) return false
      }
      return true
    })
  }, [history, q, decision, risk])

  const toggle = (id) => {
    setSelected((s) => {
      const n = new Set(s)
      n.has(id) ? n.delete(id) : n.add(id)
      return n
    })
  }
  const allSelected = filtered.length > 0 && filtered.every((h) => selected.has(h.id))
  const toggleAll = () => {
    setSelected(allSelected ? new Set() : new Set(filtered.map((h) => h.id)))
  }

  const remove = async (id) => {
    await deletePrediction(id, user.uid)
    await refreshHistory()
    toast.success('Prediction deleted')
  }
  const removeSelected = async () => {
    if (!selected.size) return
    await clearHistory(user.uid, [...selected])
    setSelected(new Set())
    await refreshHistory()
    toast.success('Selected predictions deleted')
  }
  const wipe = async () => {
    await clearHistory(user.uid)
    setSelected(new Set())
    await refreshHistory()
    toast.success('History cleared')
  }

  const view = (r) => {
    setLastPrediction(recordToPrediction(r))
    navigate('/explain')
  }

  const exportAll = (kind) => {
    const preds = filtered.map(recordToPrediction)
    if (!preds.length) return toast.error('Nothing to export')
    if (kind === 'csv') exportCSV(preds, 'lendiq-history.csv')
    else exportExcel(preds, 'lendiq-history.xlsx')
    toast.success(`History exported (${kind.toUpperCase()})`)
  }

  return (
    <div className="page">
      <div className="flex justify-between items-center" style={{ flexWrap: 'wrap', gap: 12, marginBottom: 22 }}>
        <div>
          <h1 className="page-title flex items-center gap-sm"><HistoryIcon size={24} /> Prediction History</h1>
          <p className="page-sub">Every decision is stored with your account · {history.length} records.</p>
        </div>
        <div className="flex gap-sm" style={{ flexWrap: 'wrap' }}>
          <button className="btn btn-ghost btn-sm" onClick={() => exportAll('csv')}><FileDown size={14} /> CSV</button>
          <button className="btn btn-ghost btn-sm" onClick={() => exportAll('excel')}><FileSpreadsheet size={14} /> Excel</button>
        </div>
      </div>

      {/* Filters */}
      <div className="card glass" style={{ marginBottom: 18 }}>
        <div className="flex gap-sm items-center" style={{ flexWrap: 'wrap' }}>
          <div className="topbar-search" style={{ flex: 1, minWidth: 200, width: 'auto' }}>
            <Search size={16} />
            <input placeholder="Search applicant, reason…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div className="flex items-center gap-sm">
            <Filter size={15} className="text-faint" />
            <select className="select" style={{ width: 150 }} value={decision} onChange={(e) => setDecision(e.target.value)}>
              <option value="all">All decisions</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
            <select className="select" style={{ width: 140 }} value={risk} onChange={(e) => setRisk(e.target.value)}>
              <option value="all">All risk</option>
              <option value="LOW">Low risk</option>
              <option value="MEDIUM">Medium risk</option>
              <option value="HIGH">High risk</option>
            </select>
          </div>
          {selected.size > 0 && (
            <button className="btn btn-danger btn-sm" onClick={removeSelected}><Trash2 size={14} /> Delete ({selected.size})</button>
          )}
          {history.length > 0 && <button className="btn btn-ghost btn-sm" onClick={wipe}>Clear all</button>}
        </div>
      </div>

      {/* Table */}
      <div className="card glass">
        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="ic"><HistoryIcon size={26} /></div>
            {history.length ? 'No records match your filters.' : 'No predictions stored yet.'}
          </div>
        ) : (
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th style={{ width: 40 }}>
                    <button className="icon-btn" style={{ width: 28, height: 28, border: 'none', background: 'none' }} onClick={toggleAll}>
                      {allSelected ? <CheckSquare size={17} /> : <Square size={17} />}
                    </button>
                  </th>
                  <th>Applicant</th><th>Decision</th><th>Confidence</th><th>Risk</th>
                  <th>Reason</th><th>Timestamp</th><th></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <button className="icon-btn" style={{ width: 28, height: 28, border: 'none', background: 'none' }} onClick={() => toggle(r.id)}>
                        {selected.has(r.id) ? <CheckSquare size={16} /> : <Square size={16} />}
                      </button>
                    </td>
                    <td className="mono">{r.applicantId}</td>
                    <td><span className={`badge ${r.approved ? 'badge-success' : 'badge-danger'}`}>{r.prediction}</span></td>
                    <td>{r.confidence}%</td>
                    <td><span className={`badge ${r.riskLevel === 'LOW' ? 'badge-success' : r.riskLevel === 'MEDIUM' ? 'badge-warn' : 'badge-danger'}`}>{r.riskLevel} · {r.riskScore}</span></td>
                    <td className="text-dim">{r.reason}</td>
                    <td className="text-faint">{new Date(r.timestamp).toLocaleString()}</td>
                    <td>
                      <div className="flex gap-sm">
                        <button className="icon-btn" style={{ width: 32, height: 32 }} title="Explain" onClick={() => view(r)}><Eye size={15} /></button>
                        <button className="icon-btn" style={{ width: 32, height: 32 }} title="PDF" onClick={() => exportPredictionPDF(recordToPrediction(r))}><FileText size={15} /></button>
                        <button className="icon-btn" style={{ width: 32, height: 32 }} title="Delete" onClick={() => remove(r.id)}><Trash2 size={15} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
