// ============================================================
// exportService.js
// One-click PDF / CSV / Excel exports for single predictions and
// batch results — including the SHAP summary and the AI Loan
// Advisor recommendation text.
// ============================================================
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import * as XLSX from 'xlsx'
import { buildAdvisory } from '../engine/recommendationEngine'

const BRAND = { primary: [37, 99, 235], teal: [20, 184, 166], dark: [8, 17, 32], ink: [30, 41, 59] }

function saveBlob(content, filename, type) {
  const blob = content instanceof Blob ? content : new Blob([content], { type })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1500)
}

/* ----------------------------- CSV ----------------------------- */
export function exportCSV(predictions, filename = 'lendiq-predictions.csv') {
  const rows = Array.isArray(predictions) ? predictions : [predictions]
  const headers = [
    'Applicant ID', 'Prediction', 'Confidence %', 'Approval Prob %', 'Rejection Prob %',
    'Risk Score', 'Risk Level', 'Top Reason', 'Model', 'Timestamp',
  ]
  const lines = rows.map((p) => {
    const reason = (p.approved ? p.topPositive?.[0]?.label : p.topNegative?.[0]?.label) || '—'
    return [
      p.id, p.prediction, p.confidence, p.approvalProbability, p.rejectionProbability,
      p.riskScore, p.riskLevel, reason, p.model, p.timestamp,
    ]
      .map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`)
      .join(',')
  })
  saveBlob([headers.join(','), ...lines].join('\n'), filename, 'text/csv;charset=utf-8')
}

/* ---------------------------- Excel ---------------------------- */
export function exportExcel(predictions, filename = 'lendiq-predictions.xlsx') {
  const rows = Array.isArray(predictions) ? predictions : [predictions]
  const wb = XLSX.utils.book_new()

  const summary = rows.map((p) => ({
    'Applicant ID': p.id,
    Prediction: p.prediction,
    'Confidence %': p.confidence,
    'Approval Prob %': p.approvalProbability,
    'Rejection Prob %': p.rejectionProbability,
    'Risk Score': p.riskScore,
    'Risk Level': p.riskLevel,
    'Top Reason': (p.approved ? p.topPositive?.[0]?.label : p.topNegative?.[0]?.label) || '—',
    Model: p.model,
    Timestamp: p.timestamp,
  }))
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(summary), 'Predictions')

  // SHAP contributions sheet
  const shap = []
  rows.forEach((p) => {
    ;(p.contributions || []).forEach((c) => {
      shap.push({
        'Applicant ID': p.id,
        Feature: c.label,
        Value: c.value,
        'SHAP Contribution': c.contribution,
        Impact: c.impact,
      })
    })
  })
  if (shap.length) XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(shap), 'SHAP Explanations')

  // AI recommendations sheet
  const recs = rows.map((p) => {
    const a = buildAdvisory(p)
    return {
      'Applicant ID': p.id,
      Decision: p.prediction,
      'AI Summary': a.summary,
      'Primary Reasons': a.reasons.join(' | '),
      'Recommended Actions': a.actions.join(' | '),
    }
  })
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(recs), 'AI Recommendations')

  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' })
  saveBlob(buf, filename, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
}

/* ----------------------------- PDF ----------------------------- */
function pdfHeader(docPdf, title, subtitle) {
  docPdf.setFillColor(...BRAND.dark)
  docPdf.rect(0, 0, 210, 30, 'F')
  docPdf.setFillColor(...BRAND.primary)
  docPdf.circle(18, 15, 6, 'F')
  docPdf.setTextColor(255, 255, 255)
  docPdf.setFont('helvetica', 'bold')
  docPdf.setFontSize(18)
  docPdf.text('LendIQ', 28, 14)
  docPdf.setFont('helvetica', 'normal')
  docPdf.setFontSize(8)
  docPdf.setTextColor(170, 190, 220)
  docPdf.text('Smarter Lending Decisions · Explainable AI', 28, 20)
  docPdf.setTextColor(40, 40, 40)
  docPdf.setFont('helvetica', 'bold')
  docPdf.setFontSize(15)
  docPdf.text(title, 14, 42)
  if (subtitle) {
    docPdf.setFont('helvetica', 'normal')
    docPdf.setFontSize(9)
    docPdf.setTextColor(110, 110, 110)
    docPdf.text(subtitle, 14, 48)
  }
}

/** Detailed single-applicant report. */
export function exportPredictionPDF(pred, filename) {
  const docPdf = new jsPDF()
  const advisory = buildAdvisory(pred)
  pdfHeader(docPdf, `Loan Decision Report · ${pred.id}`, `Generated ${new Date(pred.timestamp).toLocaleString()}`)

  // Decision banner
  const ok = pred.approved
  docPdf.setFillColor(...(ok ? [34, 197, 94] : [239, 68, 68]))
  docPdf.roundedRect(14, 54, 182, 18, 3, 3, 'F')
  docPdf.setTextColor(255, 255, 255)
  docPdf.setFont('helvetica', 'bold')
  docPdf.setFontSize(13)
  docPdf.text(`${ok ? 'LOAN APPROVED' : 'LOAN REJECTED'}`, 20, 65)
  docPdf.setFontSize(10)
  docPdf.text(
    `Confidence ${pred.confidence}%   ·   Risk ${pred.riskLevel} (${pred.riskScore})`,
    120, 65,
  )

  // Applicant details
  const inp = pred.input || {}
  autoTable(docPdf, {
    startY: 80,
    head: [['Applicant Details', '']],
    body: [
      ['Gender', inp.Gender], ['Married', inp.Married], ['Dependents', inp.Dependents],
      ['Education', inp.Education], ['Self Employed', inp.Self_Employed],
      ['Applicant Income', inp.ApplicantIncome], ['Coapplicant Income', inp.CoapplicantIncome],
      ['Loan Amount (k)', inp.LoanAmount], ['Loan Term (mo)', inp.Loan_Amount_Term],
      ['Credit History', inp.Credit_History], ['Property Area', inp.Property_Area],
    ],
    theme: 'striped',
    headStyles: { fillColor: BRAND.primary, fontSize: 10 },
    bodyStyles: { fontSize: 9 },
    columnStyles: { 0: { fontStyle: 'bold', cellWidth: 60 } },
  })

  // Probabilities
  autoTable(docPdf, {
    startY: docPdf.lastAutoTable.finalY + 6,
    head: [['Metric', 'Value']],
    body: [
      ['Approval Probability', `${pred.approvalProbability}%`],
      ['Rejection Probability', `${pred.rejectionProbability}%`],
      ['Risk Score', `${pred.riskScore} / 100 (${pred.riskLevel})`],
      ['Model', pred.model], ['Engine', pred.engine],
    ],
    theme: 'grid',
    headStyles: { fillColor: BRAND.teal, fontSize: 10 },
    bodyStyles: { fontSize: 9 },
  })

  // SHAP summary
  autoTable(docPdf, {
    startY: docPdf.lastAutoTable.finalY + 6,
    head: [['SHAP Feature', 'Value', 'Contribution', 'Impact']],
    body: (pred.contributions || [])
      .slice()
      .sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution))
      .map((c) => [c.label, c.value, c.contribution.toFixed(3), c.impact]),
    theme: 'striped',
    headStyles: { fillColor: BRAND.ink, fontSize: 10 },
    bodyStyles: { fontSize: 9 },
    didParseCell: (d) => {
      if (d.section === 'body' && d.column.index === 3) {
        d.cell.styles.textColor = d.cell.raw === 'positive' ? [22, 150, 80] : [200, 50, 50]
      }
    },
  })

  // AI recommendation
  let y = docPdf.lastAutoTable.finalY + 10
  if (y > 250) { docPdf.addPage(); y = 20 }
  docPdf.setFont('helvetica', 'bold')
  docPdf.setFontSize(12)
  docPdf.setTextColor(...BRAND.primary)
  docPdf.text('AI Loan Advisor', 14, y)
  y += 6
  docPdf.setFont('helvetica', 'normal')
  docPdf.setFontSize(9)
  docPdf.setTextColor(60, 60, 60)
  docPdf.text(docPdf.splitTextToSize(advisory.summary, 182), 14, y)
  y += docPdf.splitTextToSize(advisory.summary, 182).length * 4.5 + 4

  docPdf.setFont('helvetica', 'bold')
  docPdf.text('Primary Reasons', 14, y); y += 5
  docPdf.setFont('helvetica', 'normal')
  advisory.reasons.forEach((r) => { docPdf.text(`•  ${r}`, 18, y); y += 5 })
  y += 2
  docPdf.setFont('helvetica', 'bold')
  docPdf.text('Recommended Actions', 14, y); y += 5
  docPdf.setFont('helvetica', 'normal')
  advisory.actions.forEach((r) => {
    const lines = docPdf.splitTextToSize(`•  ${r}`, 178)
    docPdf.text(lines, 18, y); y += lines.length * 5
  })

  // Footer
  const pages = docPdf.internal.getNumberOfPages()
  for (let i = 1; i <= pages; i++) {
    docPdf.setPage(i)
    docPdf.setFontSize(8)
    docPdf.setTextColor(150, 150, 150)
    docPdf.text('LendIQ v1.0 · Powered by XGBoost + SHAP + Firebase · © 2026 LendIQ', 14, 290)
    docPdf.text(`Page ${i}/${pages}`, 185, 290)
  }

  saveBlob(docPdf.output('blob'), filename || `LendIQ-${pred.id}.pdf`, 'application/pdf')
}

/** Batch summary report (table of all applicants). */
export function exportBatchPDF(predictions, filename = 'LendIQ-batch-report.pdf') {
  const docPdf = new jsPDF()
  const approved = predictions.filter((p) => p.approved).length
  pdfHeader(
    docPdf,
    'Batch Decision Report',
    `${predictions.length} applicants · ${approved} approved · ${predictions.length - approved} rejected`,
  )
  autoTable(docPdf, {
    startY: 56,
    head: [['Applicant', 'Decision', 'Conf %', 'Approval %', 'Risk', 'Top Reason']],
    body: predictions.map((p) => [
      p.id, p.prediction, p.confidence, p.approvalProbability, `${p.riskLevel} (${p.riskScore})`,
      (p.approved ? p.topPositive?.[0]?.label : p.topNegative?.[0]?.label) || '—',
    ]),
    theme: 'striped',
    headStyles: { fillColor: BRAND.primary, fontSize: 9 },
    bodyStyles: { fontSize: 8 },
    didParseCell: (d) => {
      if (d.section === 'body' && d.column.index === 1) {
        d.cell.styles.textColor = d.cell.raw === 'Approved' ? [22, 150, 80] : [200, 50, 50]
        d.cell.styles.fontStyle = 'bold'
      }
    },
  })
  const pages = docPdf.internal.getNumberOfPages()
  for (let i = 1; i <= pages; i++) {
    docPdf.setPage(i)
    docPdf.setFontSize(8)
    docPdf.setTextColor(150, 150, 150)
    docPdf.text('LendIQ v1.0 · Powered by XGBoost + SHAP + Firebase · © 2026 LendIQ', 14, 290)
    docPdf.text(`Page ${i}/${pages}`, 185, 290)
  }
  saveBlob(docPdf.output('blob'), filename, 'application/pdf')
}
