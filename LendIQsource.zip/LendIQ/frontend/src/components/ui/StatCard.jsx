import AnimatedNumber from './AnimatedNumber'
import Tilt from './Tilt'

const TONES = {
  primary: { color: '#3b82f6', bg: 'rgba(37,99,235,0.18)' },
  teal: { color: '#2dd4bf', bg: 'rgba(20,184,166,0.18)' },
  success: { color: '#22c55e', bg: 'rgba(34,197,94,0.18)' },
  danger: { color: '#ef4444', bg: 'rgba(239,68,68,0.18)' },
  warning: { color: '#f59e0b', bg: 'rgba(245,158,11,0.18)' },
  violet: { color: '#a78bfa', bg: 'rgba(139,92,246,0.18)' },
}

export default function StatCard({ icon: Icon, label, value, decimals = 0, suffix = '', prefix = '', tone = 'primary', trend }) {
  const t = TONES[tone] || TONES.primary
  return (
    <Tilt className="stat-card glass" max={8}>
      <div className="glow" style={{ background: t.color }} />
      <div className="stat-ic tilt-pop" style={{ background: t.bg, color: t.color }}>
        {Icon && <Icon size={22} />}
      </div>
      <div className="stat-val tilt-pop-sm">
        <AnimatedNumber value={value} decimals={decimals} suffix={suffix} prefix={prefix} />
      </div>
      <div className="stat-label">{label}</div>
      {trend && (
        <div className="stat-trend" style={{ color: trend.up ? '#22c55e' : '#ef4444' }}>
          {trend.up ? '▲' : '▼'} {trend.text}
        </div>
      )}
    </Tilt>
  )
}
