// ============================================================
// fileParser.js
// Parses uploaded .csv / .xlsx / .xls applicant datasets into
// arrays of raw row objects, gracefully handling malformed files.
// ============================================================
import Papa from 'papaparse'
import * as XLSX from 'xlsx'

export function parseFile(file) {
  return new Promise((resolve, reject) => {
    const name = (file?.name || '').toLowerCase()
    if (!file) return reject(new Error('No file provided'))

    if (name.endsWith('.csv') || file.type === 'text/csv') {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        dynamicTyping: false,
        complete: (res) => {
          if (!res.data?.length) return reject(new Error('The CSV file appears to be empty'))
          resolve({ rows: res.data, headers: res.meta.fields || Object.keys(res.data[0]) })
        },
        error: (err) => reject(new Error(`Could not read CSV: ${err.message}`)),
      })
      return
    }

    if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const wb = XLSX.read(e.target.result, { type: 'array' })
          const sheet = wb.Sheets[wb.SheetNames[0]]
          const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' })
          if (!rows.length) return reject(new Error('The spreadsheet appears to be empty'))
          resolve({ rows, headers: Object.keys(rows[0]) })
        } catch (err) {
          reject(new Error(`Could not read spreadsheet: ${err.message}`))
        }
      }
      reader.onerror = () => reject(new Error('Failed to read the file'))
      reader.readAsArrayBuffer(file)
      return
    }

    reject(new Error('Unsupported file type. Please upload a .csv or .xlsx file.'))
  })
}

/** Build a sample template the user can download to get started. */
export const SAMPLE_ROWS = [
  {
    Loan_ID: 'LP001002', Gender: 'Male', Married: 'No', Dependents: '0', Education: 'Graduate',
    Self_Employed: 'No', ApplicantIncome: 5849, CoapplicantIncome: 0, LoanAmount: 120,
    Loan_Amount_Term: 360, Credit_History: 1, Property_Area: 'Urban',
  },
  {
    Loan_ID: 'LP001003', Gender: 'Male', Married: 'Yes', Dependents: '1', Education: 'Graduate',
    Self_Employed: 'No', ApplicantIncome: 4583, CoapplicantIncome: 1508, LoanAmount: 128,
    Loan_Amount_Term: 360, Credit_History: 1, Property_Area: 'Rural',
  },
  {
    Loan_ID: 'LP001005', Gender: 'Male', Married: 'Yes', Dependents: '0', Education: 'Not Graduate',
    Self_Employed: 'Yes', ApplicantIncome: 3000, CoapplicantIncome: 0, LoanAmount: 66,
    Loan_Amount_Term: 360, Credit_History: 1, Property_Area: 'Urban',
  },
  {
    Loan_ID: 'LP001006', Gender: 'Female', Married: 'No', Dependents: '0', Education: 'Graduate',
    Self_Employed: 'No', ApplicantIncome: 2583, CoapplicantIncome: 2358, LoanAmount: 120,
    Loan_Amount_Term: 360, Credit_History: 0, Property_Area: 'Semiurban',
  },
]
