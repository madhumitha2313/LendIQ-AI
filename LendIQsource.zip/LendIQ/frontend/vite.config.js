import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// LendIQ frontend build configuration
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
    chunkSizeWarningLimit: 1200,
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom', 'react-router-dom'],
          charts: ['recharts'],
          firebase: ['firebase/app', 'firebase/auth', 'firebase/firestore'],
          export: ['jspdf', 'jspdf-autotable', 'xlsx'],
        },
      },
    },
  },
})
