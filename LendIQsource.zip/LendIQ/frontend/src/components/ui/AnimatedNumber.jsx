// Counts up to a target value — used for animated dashboard KPIs.
import { useEffect, useRef, useState } from 'react'

export default function AnimatedNumber({ value = 0, duration = 1100, decimals = 0, prefix = '', suffix = '' }) {
  const [display, setDisplay] = useState(0)
  const ref = useRef()

  useEffect(() => {
    const start = performance.now()
    const from = 0
    const to = Number(value) || 0
    cancelAnimationFrame(ref.current)
    const tick = (now) => {
      const t = Math.min((now - start) / duration, 1)
      const eased = 1 - Math.pow(1 - t, 3) // easeOutCubic
      setDisplay(from + (to - from) * eased)
      if (t < 1) ref.current = requestAnimationFrame(tick)
    }
    ref.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(ref.current)
  }, [value, duration])

  return (
    <span>
      {prefix}
      {display.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}
      {suffix}
    </span>
  )
}
