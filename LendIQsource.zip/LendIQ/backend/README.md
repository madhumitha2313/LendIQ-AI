# LendIQ Prediction Service (FastAPI · XGBoost · SHAP)

Real XGBoost predictions with SHAP explanations, served over a small,
API-key-protected HTTP API. The React frontend uses this service when
`VITE_API_BASE_URL` is configured, and otherwise falls back to its
in-browser Edge Engine — both produce the same response shape.

## Setup

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Train the model (writes model/best_xgb.pkl).
# Drop a real Kaggle "Loan Prediction" CSV at data/loan.csv to use it;
# otherwise a schema-consistent synthetic dataset is generated.
python train_model.py

# Run the API
export LENDIQ_API_KEY=dev-secret-key          # optional
export LENDIQ_CORS_ORIGINS=http://localhost:5173
uvicorn main:app --reload --port 8000
```

The service auto-trains a model on first startup if `model/best_xgb.pkl`
is missing, so `uvicorn main:app` works even before running the script.

## Endpoints

| Method | Path             | Description                                  |
|--------|------------------|----------------------------------------------|
| GET    | `/health`        | Liveness + model/SHAP/auth status            |
| POST   | `/predict`       | Single applicant → decision + SHAP           |
| POST   | `/predict/batch` | `{ "rows": [...] }` → batch decisions         |
| GET    | `/docs`          | Interactive OpenAPI docs                      |

### Auth
If `LENDIQ_API_KEY` is set, send it as the `X-API-Key` header. The
frontend sends `VITE_API_KEY` automatically.

### Example

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -H "X-API-Key: dev-secret-key" \
  -d '{"Gender":"Male","Married":"Yes","Dependents":"0","Education":"Graduate",
       "Self_Employed":"No","ApplicantIncome":5000,"CoapplicantIncome":1500,
       "LoanAmount":120,"Loan_Amount_Term":360,"Credit_History":1,
       "Property_Area":"Semiurban"}'
```

## Wiring the frontend

In `frontend/.env`:

```
VITE_API_BASE_URL=http://localhost:8000
VITE_API_KEY=dev-secret-key
```
