import { NavLink, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, Layers, SlidersHorizontal, Sparkles, BarChart3,
  History as HistoryIcon, FileBarChart, Settings as SettingsIcon, LogOut,
} from 'lucide-react'
import Logo from '../ui/Logo'
import { useAuth } from '../../context/AuthContext'
import { useToast } from '../../context/ToastContext'

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/batch', label: 'Batch Prediction', icon: Layers },
  { to: '/manual', label: 'Manual Prediction', icon: SlidersHorizontal },
  { to: '/explain', label: 'Explain AI', icon: Sparkles },
  { to: '/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/history', label: 'Prediction History', icon: HistoryIcon },
  { to: '/reports', label: 'Reports', icon: FileBarChart },
  { to: '/settings', label: 'Settings', icon: SettingsIcon },
]

export default function Sidebar({ open, onClose }) {
  const { user, logout } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()

  const handleLogout = async () => {
    await logout()
    toast.success('Signed out securely')
    navigate('/login')
  }

  const initials = (user?.name || user?.email || 'U').slice(0, 2).toUpperCase()

  return (
    <>
      {open && <div className="sidebar-backdrop" onClick={onClose} />}
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="sidebar-brand">
          <Logo size={38} />
          <div>
            <div className="brand-name">Lend<span style={{ color: '#5eead4' }}>IQ</span></div>
            <div className="brand-tag">EXPLAINABLE AI LENDING</div>
          </div>
        </div>

        <div className="nav-section-label">Menu</div>
        <nav className="nav">
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              onClick={onClose}
              className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
            >
              <Icon size={18} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="nav-spacer" />

        <div className="sidebar-user">
          <div className="avatar">{initials}</div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 13.5, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {user?.name || 'User'}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-faint)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {user?.email}
            </div>
          </div>
        </div>

        <button className="nav-item" style={{ marginTop: 6, color: '#fca5a5' }} onClick={handleLogout}>
          <LogOut size={18} />
          <span>Logout</span>
        </button>
      </aside>
    </>
  )
}
