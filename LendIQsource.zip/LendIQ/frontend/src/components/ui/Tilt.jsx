// 3D tilt-on-hover with a moving glare highlight.
import { useRef, useCallback } from 'react'

export default function Tilt({ children, max = 9, scale = 1.02, glare = true, className = '', style }) {
  const ref = useRef(null)
  const raf = useRef(0)

  const onMove = useCallback(
    (e) => {
      const el = ref.current
      if (!el) return
      const r = el.getBoundingClientRect()
      const px = (e.clientX - r.left) / r.width
      const py = (e.clientY - r.top) / r.height
      const rx = (0.5 - py) * max * 2
      const ry = (px - 0.5) * max * 2
      cancelAnimationFrame(raf.current)
      raf.current = requestAnimationFrame(() => {
        el.style.transform = `perspective(1000px) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg) scale(${scale})`
        const g = el.querySelector('.tilt-glare')
        if (g) g.style.background = `radial-gradient(circle at ${(px * 100).toFixed(0)}% ${(py * 100).toFixed(0)}%, rgba(255,255,255,0.20), transparent 50%)`
      })
    },
    [max, scale],
  )

  const onLeave = useCallback(() => {
    const el = ref.current
    if (!el) return
    cancelAnimationFrame(raf.current)
    el.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)'
    const g = el.querySelector('.tilt-glare')
    if (g) g.style.background = 'transparent'
  }, [])

  return (
    <div ref={ref} className={`tilt ${className}`} style={style} onMouseMove={onMove} onMouseLeave={onLeave}>
      {children}
      {glare && <span className="tilt-glare" />}
    </div>
  )
}
