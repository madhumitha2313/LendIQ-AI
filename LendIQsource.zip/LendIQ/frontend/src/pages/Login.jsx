import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { Mail, Lock, Eye, EyeOff, User, ShieldCheck, BrainCircuit, Zap, ArrowRight } from 'lucide-react'
import Logo from '../components/ui/Logo'
import Particles from '../components/ui/Particles'
import Card3D from '../components/ui/Card3D'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

const FEATURES = [
  { icon: BrainCircuit, title: 'Explainable AI', text: 'Every decision is backed by SHAP feature attributions you can defend.' },
  { icon: Zap, title: 'Instant Scoring', text: 'XGBoost-grade approvals, confidence and risk in milliseconds.' },
  { icon: ShieldCheck, title: 'Bank-grade Security', text: 'Firebase authentication with full session management.' },
]

export default function Login() {
  const [isSignup, setIsSignup] = useState(false)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [remember, setRemember] = useState(true)
  const [busy, setBusy] = useState(false)
  const { login, signup, mode } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()
  const location = useLocation()
  const from = location.state?.from?.pathname || '/dashboard'

  const submit = async (e) => {
    e.preventDefault()
    if (!email || !password) return toast.error('Please enter email and password')
    if (password.length < 6) return toast.error('Password must be at least 6 characters')
    setBusy(true)
    try {
      if (isSignup) {
        await signup(name, email, password)
        toast.success('Account created — welcome to LendIQ!')
      } else {
        await login(email, password, remember)
        toast.success('Welcome back!')
      }
      navigate(from, { replace: true })
    } catch (err) {
      toast.error(err.message || 'Authentication failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="auth-wrap">
      {/* Hero */}
      <div className="auth-hero">
        <div className="auth-hero-glow" style={{ background: '#2563eb', top: -120, left: -80 }} />
        <div className="auth-hero-glow" style={{ background: '#14b8a6', bottom: -120, right: -60 }} />
        <Particles density={48} />
        <div style={{ position: 'relative', zIndex: 1 }}>
          <Logo size={46} withText />
        </div>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 6 }}>
            <Card3D />
          </div>
          <h1 style={{ fontSize: 40, lineHeight: 1.1, marginBottom: 14 }}>
            Smarter lending,<br /><span className="gradient-text">fully explained.</span>
          </h1>
          <p style={{ color: 'var(--text-dim)', maxWidth: 420, marginBottom: 28, fontSize: 15 }}>
            LendIQ turns raw applications into transparent, defensible credit decisions —
            with risk intelligence and AI recommendations on every call.
          </p>
          {FEATURES.map((f) => (
            <div className="auth-feature" key={f.title}>
              <div className="fi"><f.icon size={18} color="#5eead4" /></div>
              <div>
                <div style={{ fontWeight: 700, fontSize: 14.5 }}>{f.title}</div>
                <div style={{ color: 'var(--text-faint)', fontSize: 13 }}>{f.text}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ position: 'relative', color: 'var(--text-faint)', fontSize: 12.5 }}>
          © 2026 LendIQ · Powered by XGBoost + SHAP + Firebase
        </div>
      </div>

      {/* Form panel */}
      <div className="auth-panel">
        <div className="auth-card glass-strong glass">
          <div style={{ marginBottom: 22 }}>
            <h2>{isSignup ? 'Create your account' : 'Sign in to LendIQ'}</h2>
            <p className="text-dim" style={{ fontSize: 13.5, marginTop: 6 }}>
              {isSignup ? 'Start making explainable lending decisions.' : 'Welcome back. Please enter your details.'}
            </p>
          </div>

          <form onSubmit={submit} className="grid" style={{ gap: 16 }}>
            {isSignup && (
              <div className="field">
                <label>Full name</label>
                <div className="auth-input-wrap">
                  <input className="input" style={{ paddingLeft: 40 }} placeholder="Jane Doe" value={name} onChange={(e) => setName(e.target.value)} />
                  <User size={16} style={{ position: 'absolute', left: 14, top: 14, color: 'var(--text-faint)' }} />
                </div>
              </div>
            )}
            <div className="field">
              <label>Email address</label>
              <div className="auth-input-wrap">
                <input className="input" style={{ paddingLeft: 40 }} type="email" placeholder="you@company.com" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
                <Mail size={16} style={{ position: 'absolute', left: 14, top: 14, color: 'var(--text-faint)' }} />
              </div>
            </div>
            <div className="field">
              <label>Password</label>
              <div className="auth-input-wrap">
                <input className="input" style={{ paddingLeft: 40, paddingRight: 40 }} type={showPw ? 'text' : 'password'} placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={isSignup ? 'new-password' : 'current-password'} />
                <Lock size={16} style={{ position: 'absolute', left: 14, top: 14, color: 'var(--text-faint)' }} />
                <button type="button" className="eye" onClick={() => setShowPw((s) => !s)} aria-label="Toggle password">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {!isSignup && (
              <div className="flex justify-between items-center">
                <label className="checkbox-row">
                  <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
                  Remember me
                </label>
                <Link to="/forgot-password" style={{ fontSize: 13, color: 'var(--primary-soft)', fontWeight: 600 }}>
                  Forgot password?
                </Link>
              </div>
            )}

            <button className="btn btn-primary btn-block" disabled={busy} type="submit">
              {busy ? <span className="spinner" /> : <>{isSignup ? 'Create account' : 'Sign in'} <ArrowRight size={16} /></>}
            </button>
          </form>

          <div style={{ textAlign: 'center', marginTop: 18, fontSize: 13.5, color: 'var(--text-dim)' }}>
            {isSignup ? 'Already have an account?' : "Don't have an account?"}{' '}
            <button onClick={() => setIsSignup((s) => !s)} style={{ background: 'none', border: 'none', color: 'var(--primary-soft)', fontWeight: 700, cursor: 'pointer', fontSize: 13.5 }}>
              {isSignup ? 'Sign in' : 'Create one'}
            </button>
          </div>

          {mode === 'demo' && (
            <div style={{ marginTop: 18, padding: '11px 13px', borderRadius: 11, background: 'rgba(37,99,235,0.1)', border: '1px solid rgba(37,99,235,0.25)', fontSize: 12.5, color: 'var(--text-dim)' }}>
              <strong style={{ color: '#93c5fd' }}>Demo mode:</strong> Firebase isn't configured, so accounts are stored locally in this browser. Sign up with any email to explore LendIQ instantly.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
