import { useEffect, useState } from 'react'
import {
  Settings as SettingsIcon, User, Sun, Moon, Bell, Database, KeyRound, Info,
  ShieldCheck, Server, Cpu, CheckCircle2, XCircle,
} from 'lucide-react'
import { useTheme } from '../context/ThemeContext'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { firebaseEnabled } from '../firebase/config'
import { apiEnabled, apiHealth } from '../services/predictionApi'
import { MODEL_INFO } from '../engine/scoringEngine'

function Toggle({ on, onChange }) {
  return (
    <button
      onClick={() => onChange(!on)}
      style={{
        width: 46, height: 26, borderRadius: 999, border: 'none', cursor: 'pointer',
        background: on ? 'linear-gradient(120deg,#2563eb,#14b8a6)' : 'rgba(255,255,255,0.15)',
        position: 'relative', transition: '0.2s',
      }}
      aria-pressed={on}
    >
      <span style={{
        position: 'absolute', top: 3, left: on ? 23 : 3, width: 20, height: 20, borderRadius: '50%',
        background: '#fff', transition: 'left 0.2s',
      }} />
    </button>
  )
}

function Row({ icon: Icon, title, desc, children }) {
  return (
    <div className="flex justify-between items-center" style={{ padding: '14px 0', borderBottom: '1px solid var(--stroke)', gap: 16, flexWrap: 'wrap' }}>
      <div className="flex items-center gap-sm" style={{ gap: 13 }}>
        {Icon && <div style={{ width: 38, height: 38, borderRadius: 11, display: 'grid', placeItems: 'center', background: 'var(--card)', border: '1px solid var(--stroke)', flexShrink: 0 }}><Icon size={17} /></div>}
        <div>
          <div style={{ fontWeight: 600, fontSize: 14 }}>{title}</div>
          {desc && <div className="text-faint" style={{ fontSize: 12.5 }}>{desc}</div>}
        </div>
      </div>
      <div>{children}</div>
    </div>
  )
}

export default function Settings() {
  const { theme, setTheme } = useTheme()
  const { user, resetPassword, mode } = useAuth()
  const toast = useToast()
  const [notif, setNotif] = useState(() => localStorage.getItem('lendiq:notif') !== 'off')
  const [emailReports, setEmailReports] = useState(() => localStorage.getItem('lendiq:emailReports') === 'on')
  const [apiStatus, setApiStatus] = useState({ enabled: apiEnabled, ok: false })

  useEffect(() => { apiHealth().then(setApiStatus) }, [])
  useEffect(() => { localStorage.setItem('lendiq:notif', notif ? 'on' : 'off') }, [notif])
  useEffect(() => { localStorage.setItem('lendiq:emailReports', emailReports ? 'on' : 'off') }, [emailReports])

  const doReset = async () => {
    try {
      await resetPassword(user.email)
      toast.success(firebaseEnabled ? 'Password reset email sent' : 'Reset is available in Firebase mode')
    } catch (e) {
      toast.error(e.message)
    }
  }

  return (
    <div className="page">
      <div style={{ marginBottom: 22 }}>
        <h1 className="page-title flex items-center gap-sm"><SettingsIcon size={24} /> Settings</h1>
        <p className="page-sub">Manage your profile, appearance, integrations and account.</p>
      </div>

      <div className="section-grid-2" style={{ marginBottom: 18 }}>
        {/* Profile */}
        <div className="card glass">
          <div className="card-head"><h3 className="flex items-center gap-sm"><User size={17} /> Profile</h3></div>
          <div className="flex items-center gap-sm" style={{ gap: 14, marginBottom: 16 }}>
            <div className="avatar" style={{ width: 56, height: 56, fontSize: 20, borderRadius: 16 }}>
              {(user?.name || user?.email || 'U').slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 16 }}>{user?.name || 'User'}</div>
              <div className="text-faint" style={{ fontSize: 13 }}>{user?.email}</div>
              <span className="badge badge-teal" style={{ marginTop: 6 }}>{mode === 'firebase' ? 'Firebase account' : 'Local account'}</span>
            </div>
          </div>
          <div className="field">
            <label>Display name</label>
            <input className="input" defaultValue={user?.name} placeholder="Your name" />
          </div>
          <div className="field" style={{ marginTop: 12 }}>
            <label>Email</label>
            <input className="input" value={user?.email || ''} disabled />
          </div>
          <button className="btn btn-ghost btn-sm" style={{ marginTop: 14 }} onClick={() => toast.success('Profile saved')}>Save changes</button>
        </div>

        {/* Appearance + notifications */}
        <div className="card glass">
          <div className="card-head"><h3 className="flex items-center gap-sm"><Sun size={17} /> Appearance & Notifications</h3></div>
          <Row icon={theme === 'dark' ? Moon : Sun} title="Theme" desc="Switch between dark and light mode">
            <div className="seg-tabs">
              <button className={`seg-tab ${theme === 'dark' ? 'active' : ''}`} onClick={() => setTheme('dark')}>Dark</button>
              <button className={`seg-tab ${theme === 'light' ? 'active' : ''}`} onClick={() => setTheme('light')}>Light</button>
            </div>
          </Row>
          <Row icon={Bell} title="In-app notifications" desc="Toasts for predictions and exports">
            <Toggle on={notif} onChange={setNotif} />
          </Row>
          <Row icon={Bell} title="Email reports" desc="Email me a copy of generated reports">
            <Toggle on={emailReports} onChange={setEmailReports} />
          </Row>
        </div>
      </div>

      <div className="section-grid-2" style={{ marginBottom: 18 }}>
        {/* Integrations */}
        <div className="card glass">
          <div className="card-head"><h3 className="flex items-center gap-sm"><Server size={17} /> Integrations</h3></div>
          <Row icon={Database} title="Firebase" desc="Authentication & Firestore history">
            <span className={`badge ${firebaseEnabled ? 'badge-success' : 'badge-warn'}`}>
              {firebaseEnabled ? <><CheckCircle2 size={12} /> Connected</> : <>Demo (local)</>}
            </span>
          </Row>
          <Row icon={Cpu} title="FastAPI prediction service" desc="Real XGBoost + SHAP backend">
            <span className={`badge ${apiStatus.enabled ? (apiStatus.ok ? 'badge-success' : 'badge-danger') : 'badge-info'}`}>
              {apiStatus.enabled ? (apiStatus.ok ? <><CheckCircle2 size={12} /> Online</> : <><XCircle size={12} /> Offline</>) : 'Edge Engine'}
            </span>
          </Row>
          <Row icon={ShieldCheck} title="Scoring engine" desc="Active prediction source">
            <span className="badge badge-teal">{apiStatus.enabled && apiStatus.ok ? 'XGBoost (API)' : MODEL_INFO.edgeEngine}</span>
          </Row>
        </div>

        {/* Account / security */}
        <div className="card glass">
          <div className="card-head"><h3 className="flex items-center gap-sm"><KeyRound size={17} /> Account & Security</h3></div>
          <Row icon={KeyRound} title="Reset password" desc="Send a password reset email">
            <button className="btn btn-ghost btn-sm" onClick={doReset}>Reset</button>
          </Row>
          <Row icon={ShieldCheck} title="Session" desc={`Signed in via ${mode === 'firebase' ? 'Firebase Auth' : 'local session'}`}>
            <span className="badge badge-info">Active</span>
          </Row>
        </div>
      </div>

      {/* About */}
      <div className="card glass">
        <div className="card-head"><h3 className="flex items-center gap-sm"><Info size={17} /> About LendIQ</h3></div>
        <div className="section-grid-3">
          <div className="kpi-pill"><div className="l">Version</div><div className="v" style={{ fontSize: 17 }}>1.0.0</div></div>
          <div className="kpi-pill"><div className="l">Model</div><div className="v" style={{ fontSize: 17 }}>{MODEL_INFO.name}</div></div>
          <div className="kpi-pill"><div className="l">Accuracy</div><div className="v" style={{ fontSize: 17, color: '#5eead4' }}>{MODEL_INFO.accuracy}%</div></div>
        </div>
        <p className="text-faint" style={{ fontSize: 12.5, marginTop: 16 }}>
          LendIQ · Smarter Lending Decisions Powered by Explainable AI · Powered by XGBoost + SHAP + Firebase · © 2026 LendIQ.
        </p>
      </div>
    </div>
  )
}
