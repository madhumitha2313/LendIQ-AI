// Framer Motion reveal helpers for staggered, on-enter animations.
import { motion } from 'framer-motion'

export function Reveal({ children, delay = 0, y = 18, className = '', style }) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
      style={style}
    >
      {children}
    </motion.div>
  )
}

export const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07, delayChildren: 0.05 } },
}
export const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] } },
}

export function StaggerGrid({ children, className = '', style }) {
  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className={className} style={style}>
      {children}
    </motion.div>
  )
}

export function StaggerItem({ children, className = '', style }) {
  return (
    <motion.div variants={item} className={className} style={style}>
      {children}
    </motion.div>
  )
}
