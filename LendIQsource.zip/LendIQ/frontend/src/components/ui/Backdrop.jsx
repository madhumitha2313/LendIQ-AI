// Animated aurora backdrop with drifting orbs + perspective grid floor.
export default function Backdrop({ grid = true }) {
  return (
    <>
      <div className="app-backdrop" />
      <div className="fx-backdrop">
        <span className="fx-orb o1" />
        <span className="fx-orb o2" />
        <span className="fx-orb o3" />
        {grid && <div className="fx-grid" />}
      </div>
    </>
  )
}
