// ============================================================
// AuthContext
// Unified auth surface over Firebase Authentication with a
// transparent local/demo fallback so LendIQ runs end-to-end
// even when Firebase credentials are not configured.
// ============================================================
import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { auth, firebaseEnabled } from '../firebase/config'
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  sendEmailVerification,
  updateProfile,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
} from 'firebase/auth'

const AuthContext = createContext(null)
export const useAuth = () => useContext(AuthContext)

const LS_USERS = 'lendiq:users'
const LS_SESSION = 'lendiq:session'

/* ---------- local/demo helpers (used only when Firebase is off) ---------- */
const readUsers = () => {
  try { return JSON.parse(localStorage.getItem(LS_USERS) || '{}') } catch { return {} }
}
const writeUsers = (u) => localStorage.setItem(LS_USERS, JSON.stringify(u))
// tiny non-cryptographic hash — demo fallback only, never use for real secrets
const hash = (s) => {
  let h = 5381
  for (let i = 0; i < s.length; i++) h = (h * 33) ^ s.charCodeAt(i)
  return (h >>> 0).toString(16)
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [mode] = useState(firebaseEnabled ? 'firebase' : 'demo')

  useEffect(() => {
    if (firebaseEnabled && auth) {
      const unsub = onAuthStateChanged(auth, (fbUser) => {
        setUser(
          fbUser
            ? {
                uid: fbUser.uid,
                email: fbUser.email,
                name: fbUser.displayName || fbUser.email?.split('@')[0],
                verified: fbUser.emailVerified,
              }
            : null,
        )
        setLoading(false)
      })
      return unsub
    }
    // demo mode: restore session from storage
    try {
      const s = JSON.parse(localStorage.getItem(LS_SESSION) || 'null')
      if (s) setUser(s)
    } catch { /* ignore */ }
    setLoading(false)
  }, [])

  const login = useCallback(async (email, password, remember = true) => {
    email = email.trim().toLowerCase()
    if (firebaseEnabled && auth) {
      await setPersistence(auth, remember ? browserLocalPersistence : browserSessionPersistence)
      try {
        await signInWithEmailAndPassword(auth, email, password)
      } catch {
        throw new Error('Incorrect Email or Password')
      }
      return
    }
    // demo
    const users = readUsers()
    const rec = users[email]
    if (!rec || rec.pw !== hash(password)) throw new Error('Incorrect Email or Password')
    const session = { uid: email, email, name: rec.name, verified: true }
    setUser(session)
    localStorage.setItem(LS_SESSION, JSON.stringify(session))
  }, [])

  const signup = useCallback(async (name, email, password) => {
    email = email.trim().toLowerCase()
    if (firebaseEnabled && auth) {
      const cred = await createUserWithEmailAndPassword(auth, email, password)
      if (name) await updateProfile(cred.user, { displayName: name })
      try { await sendEmailVerification(cred.user) } catch { /* non-fatal */ }
      return
    }
    const users = readUsers()
    if (users[email]) throw new Error('An account with this email already exists')
    users[email] = { name: name || email.split('@')[0], pw: hash(password) }
    writeUsers(users)
    const session = { uid: email, email, name: users[email].name, verified: true }
    setUser(session)
    localStorage.setItem(LS_SESSION, JSON.stringify(session))
  }, [])

  const resetPassword = useCallback(async (email) => {
    email = email.trim().toLowerCase()
    if (firebaseEnabled && auth) {
      await sendPasswordResetEmail(auth, email)
      return
    }
    const users = readUsers()
    if (!users[email]) throw new Error('No account found for this email')
    // demo: just confirm — a real reset email is sent in Firebase mode
  }, [])

  const logout = useCallback(async () => {
    if (firebaseEnabled && auth) {
      await signOut(auth)
    } else {
      localStorage.removeItem(LS_SESSION)
      setUser(null)
    }
  }, [])

  const value = { user, loading, mode, login, signup, resetPassword, logout }
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
