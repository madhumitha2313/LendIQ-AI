// ============================================================
// PredictionContext
// Shares the most-recent single prediction and batch results
// across pages (Explain AI, Reports) and exposes history-derived
// dashboard statistics.
// ============================================================
import { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { useAuth } from './AuthContext'
import { listPredictions } from '../services/historyService'

const PredictionContext = createContext(null)
export const usePrediction = () => useContext(PredictionContext)

const SS_LAST = 'lendiq:lastPrediction'
const SS_BATCH = 'lendiq:lastBatch'

export function PredictionProvider({ children }) {
  const { user } = useAuth()
  const [lastPrediction, setLastPredictionState] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem(SS_LAST) || 'null') } catch { return null }
  })
  const [batchResults, setBatchResultsState] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem(SS_BATCH) || '[]') } catch { return [] }
  })
  const [history, setHistory] = useState([])
  const [loadingHistory, setLoadingHistory] = useState(false)

  const setLastPrediction = useCallback((p) => {
    setLastPredictionState(p)
    try { sessionStorage.setItem(SS_LAST, JSON.stringify(p)) } catch { /* ignore */ }
  }, [])

  const setBatchResults = useCallback((rows) => {
    setBatchResultsState(rows)
    try { sessionStorage.setItem(SS_BATCH, JSON.stringify(rows)) } catch { /* ignore */ }
  }, [])

  const refreshHistory = useCallback(async () => {
    if (!user) return setHistory([])
    setLoadingHistory(true)
    try {
      setHistory(await listPredictions(user.uid))
    } catch (e) {
      console.warn('[LendIQ] history load failed:', e.message)
    } finally {
      setLoadingHistory(false)
    }
  }, [user])

  useEffect(() => { refreshHistory() }, [refreshHistory])

  const value = {
    lastPrediction, setLastPrediction,
    batchResults, setBatchResults,
    history, refreshHistory, loadingHistory,
  }
  return <PredictionContext.Provider value={value}>{children}</PredictionContext.Provider>
}
