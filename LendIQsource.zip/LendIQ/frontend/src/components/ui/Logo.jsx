// Brand mark used across splash, auth and sidebar.
export default function Logo({ size = 40, withText = false }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
      <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-label="LendIQ">
        <defs>
          <linearGradient id={`lg${size}`} x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#2563EB" />
            <stop offset="1" stopColor="#14B8A6" />
          </linearGradient>
        </defs>
        <rect x="4" y="4" width="56" height="56" rx="16" fill={`url(#lg${size})`} />
        <rect x="4" y="4" width="56" height="56" rx="16" fill="#ffffff" fillOpacity="0.06" />
        <path d="M18 40V22" stroke="#fff" strokeWidth="4.5" strokeLinecap="round" />
        <path d="M18 40h12" stroke="#fff" strokeWidth="4.5" strokeLinecap="round" />
        <circle cx="42" cy="27" r="7.5" stroke="#fff" strokeWidth="4.5" />
        <path d="M47.5 32.5L52 37" stroke="#fff" strokeWidth="4.5" strokeLinecap="round" />
      </svg>
      {withText && (
        <div>
          <div style={{ fontSize: size * 0.5, fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1 }}>
            Lend<span style={{ color: '#5eead4' }}>IQ</span>
          </div>
        </div>
      )}
    </div>
  )
}
