// ============================================================
// demoData.js — generate realistic synthetic applicants so the
// dashboard/analytics feel alive before real predictions exist.
// ============================================================
import { scoreApplicant } from '../engine/scoringEngine'

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]
const randn = () => {
  let u = 0, v = 0
  while (u === 0) u = Math.random()
  while (v === 0) v = Math.random()
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v)
}
const clampInt = (n, min, max) => Math.max(min, Math.min(max, Math.round(n)))

export function randomApplicant(i = 0) {
  return {
    Loan_ID: `LP${(100000 + Math.floor(Math.random() * 899999))}`,
    Gender: pick(['Male', 'Male', 'Female']),
    Married: pick(['Yes', 'Yes', 'No']),
    Dependents: pick(['0', '0', '1', '2', '3+']),
    Education: pick(['Graduate', 'Graduate', 'Graduate', 'Not Graduate']),
    Self_Employed: pick(['No', 'No', 'No', 'Yes']),
    ApplicantIncome: clampInt(4500 + randn() * 2600, 1200, 22000),
    CoapplicantIncome: pick([0, 0, clampInt(1500 + randn() * 1400, 0, 9000)]),
    LoanAmount: clampInt(135 + randn() * 70, 30, 600),
    Loan_Amount_Term: pick([360, 360, 360, 180, 240, 120]),
    Credit_History: Math.random() < 0.84 ? 1 : 0,
    Property_Area: pick(['Urban', 'Semiurban', 'Semiurban', 'Rural']),
  }
}

/** Generate N scored predictions spread across the last `daysBack` days. */
export function generateDemoPredictions(n = 40, daysBack = 7) {
  const out = []
  for (let i = 0; i < n; i++) {
    const pred = scoreApplicant(randomApplicant(i))
    const d = new Date()
    d.setDate(d.getDate() - Math.floor(Math.random() * daysBack))
    d.setHours(Math.floor(Math.random() * 24), Math.floor(Math.random() * 60))
    pred.timestamp = d.toISOString()
    out.push(pred)
  }
  return out.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
}
