// SHAP waterfall: base value → cumulative contributions → final prediction.
export default function ShapWaterfall({ pred, max = 7 }) {
  if (!pred) return null
  const base = pred.baseValue ?? 50
  const items = [...(pred.contributions || [])]
    .sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution))
    .slice(0, max)

  // Convert log-odds contributions into approximate probability deltas that
  // sum to the gap between base and final probability (for a readable chart).
  const totalContrib = items.reduce((s, c) => s + c.contribution, 0) || 1
  const gap = pred.approvalProbability - base
  const steps = []
  let cum = base
  items.forEach((c) => {
    const delta = (c.contribution / totalContrib) * gap
    steps.push({ label: c.label, from: cum, delta, positive: delta >= 0 })
    cum += delta
  })

  const minV = Math.min(base, pred.approvalProbability, ...steps.map((s) => Math.min(s.from, s.from + s.delta)))
  const maxV = Math.max(base, pred.approvalProbability, ...steps.map((s) => Math.max(s.from, s.from + s.delta)))
  const range = Math.max(maxV - minV, 1)
  const x = (v) => ((v - minV) / range) * 100

  return (
    <div>
      <div className="shap-row">
        <div className="name" style={{ color: 'var(--text)' }}>Base value</div>
        <div className="track">
          <div className="shap-bar-seg" style={{ position: 'absolute', left: 0, width: `${x(base)}%`, background: 'rgba(148,163,184,0.45)' }} />
        </div>
        <div className="val">{base.toFixed(1)}%</div>
      </div>
      {steps.map((s, i) => {
        const a = x(s.from)
        const b = x(s.from + s.delta)
        const left = Math.min(a, b)
        const width = Math.max(Math.abs(b - a), 0.6)
        return (
          <div className="shap-row" key={i}>
            <div className="name" title={s.label}>{s.label}</div>
            <div className="track">
              <div
                className="shap-bar-seg"
                style={{
                  position: 'absolute', left: `${left}%`, width: `${width}%`,
                  background: s.positive ? 'linear-gradient(90deg,#16a34a,#22c55e)' : 'linear-gradient(90deg,#ef4444,#f87171)',
                }}
              />
            </div>
            <div className="val" style={{ color: s.positive ? '#4ade80' : '#f87171' }}>
              {s.positive ? '+' : ''}{s.delta.toFixed(1)}
            </div>
          </div>
        )
      })}
      <div className="shap-row">
        <div className="name" style={{ color: 'var(--text)', fontWeight: 700 }}>Prediction</div>
        <div className="track">
          <div className="shap-bar-seg" style={{ position: 'absolute', left: 0, width: `${x(pred.approvalProbability)}%`, background: 'linear-gradient(90deg,#2563eb,#14b8a6)' }} />
        </div>
        <div className="val" style={{ fontWeight: 700 }}>{pred.approvalProbability.toFixed(1)}%</div>
      </div>
    </div>
  )
}
