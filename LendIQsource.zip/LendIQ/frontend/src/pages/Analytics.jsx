import { useMemo } from 'react'
import {
  BarChart3, PieChart as PieIcon, Wand2, TrendingUp, Building2, CreditCard, Gauge,
} from 'lucide-react'
import {
  ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip,
  AreaChart, Area, RadialBarChart, RadialBar, Legend,
} from 'recharts'
import { globalImportance } from '../engine/scoringEngine'
import { generateDemoPredictions } from '../data/demoData'
import { savePredictions } from '../services/historyService'
import { usePrediction } from '../context/PredictionContext'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

const COLORS = ['#2563eb', '#14b8a6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6']
const tooltipStyle = { background: '#0b1730', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 12 }

function analyse(history) {
  const inputOf = (h) => h.snapshot?.input || {}
  const approvalDist = [
    { name: 'Approved', value: history.filter((h) => h.approved).length },
    { name: 'Rejected', value: history.filter((h) => !h.approved).length },
  ]
  const riskDist = ['LOW', 'MEDIUM', 'HIGH'].map((lvl, i) => ({
    name: lvl, value: history.filter((h) => h.riskLevel === lvl).length, fill: ['#22c55e', '#f59e0b', '#ef4444'][i],
  }))
  const confBuckets = ['50-60', '60-70', '70-80', '80-90', '90-100'].map((label, i) => ({
    range: label, count: history.filter((h) => h.confidence >= 50 + i * 10 && h.confidence < 60 + i * 10).length,
  }))
  const areaDist = ['Urban', 'Semiurban', 'Rural'].map((a) => ({
    name: a, value: history.filter((h) => inputOf(h).Property_Area === a).length,
  }))
  const creditDist = [
    { name: 'Good (1)', value: history.filter((h) => Number(inputOf(h).Credit_History) === 1).length },
    { name: 'Poor (0)', value: history.filter((h) => Number(inputOf(h).Credit_History) === 0).length },
  ]
  const incomeBuckets = [
    { range: '<3k', count: 0 }, { range: '3-6k', count: 0 }, { range: '6-10k', count: 0 }, { range: '10k+', count: 0 },
  ]
  history.forEach((h) => {
    const inc = (Number(inputOf(h).ApplicantIncome) || 0) + (Number(inputOf(h).CoapplicantIncome) || 0)
    if (inc < 3000) incomeBuckets[0].count++
    else if (inc < 6000) incomeBuckets[1].count++
    else if (inc < 10000) incomeBuckets[2].count++
    else incomeBuckets[3].count++
  })
  // 14-day trend
  const trend = []
  for (let i = 13; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i)
    const key = d.toDateString()
    const onDay = history.filter((h) => new Date(h.timestamp).toDateString() === key)
    trend.push({ day: d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }), predictions: onDay.length })
  }
  return { approvalDist, riskDist, confBuckets, areaDist, creditDist, incomeBuckets, trend }
}

function ChartCard({ title, icon: Icon, sub, children }) {
  return (
    <div className="card glass">
      <div className="card-head">
        <h3 className="flex items-center gap-sm">{Icon && <Icon size={17} />} {title}</h3>
        {sub && <span className="sub">{sub}</span>}
      </div>
      {children}
    </div>
  )
}

export default function Analytics() {
  const { history, refreshHistory } = usePrediction()
  const { user } = useAuth()
  const toast = useToast()
  const a = useMemo(() => analyse(history), [history])
  const global = globalImportance()

  const loadDemo = async () => {
    const preds = generateDemoPredictions(45)
    if (user) {
      await savePredictions(preds, user.uid, 'demo')
      await refreshHistory()
    }
    toast.success('Loaded 45 demo predictions')
  }

  if (!history.length) {
    return (
      <div className="page">
        <h1 className="page-title flex items-center gap-sm"><BarChart3 size={24} /> Analytics</h1>
        <p className="page-sub" style={{ marginBottom: 22 }}>Interactive portfolio intelligence.</p>
        <div className="card glass empty-state">
          <div className="ic"><BarChart3 size={26} /></div>
          No data to analyse yet. Generate a realistic demo portfolio to explore the analytics suite.
          <div style={{ marginTop: 16 }}>
            <button className="btn btn-primary" onClick={loadDemo}><Wand2 size={16} /> Generate demo data</button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="page">
      <div className="flex justify-between items-center" style={{ flexWrap: 'wrap', gap: 12, marginBottom: 22 }}>
        <div>
          <h1 className="page-title flex items-center gap-sm"><BarChart3 size={24} /> Analytics</h1>
          <p className="page-sub">Interactive portfolio intelligence across {history.length} predictions.</p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={loadDemo}><Wand2 size={15} /> Add demo data</button>
      </div>

      <div className="section-grid-2" style={{ marginBottom: 18 }}>
        <ChartCard title="Approval vs Rejection" icon={PieIcon} sub="all-time">
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={a.approvalDist} dataKey="value" innerRadius={55} outerRadius={90} paddingAngle={3} stroke="none">
                <Cell fill="#22c55e" /><Cell fill="#ef4444" />
              </Pie>
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Prediction Trend" icon={TrendingUp} sub="last 14 days">
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={a.trend} margin={{ left: -22, right: 6 }}>
              <defs>
                <linearGradient id="tg" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2563eb" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#2563eb" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" stroke="#6b7a96" fontSize={11} tickLine={false} axisLine={false} interval={2} />
              <YAxis stroke="#6b7a96" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip contentStyle={tooltipStyle} />
              <Area type="monotone" dataKey="predictions" stroke="#3b82f6" strokeWidth={2.5} fill="url(#tg)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="section-grid-3" style={{ marginBottom: 18 }}>
        <ChartCard title="Risk Distribution" icon={Gauge}>
          <ResponsiveContainer width="100%" height={220}>
            <RadialBarChart innerRadius="30%" outerRadius="100%" data={a.riskDist} startAngle={90} endAngle={-270}>
              <RadialBar minAngle={15} background dataKey="value" cornerRadius={8} />
              <Legend iconSize={9} layout="vertical" verticalAlign="middle" align="right" />
              <Tooltip contentStyle={tooltipStyle} />
            </RadialBarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Property Area" icon={Building2}>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={a.areaDist}>
              <XAxis dataKey="name" stroke="#6b7a96" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#6b7a96" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip cursor={{ fill: 'rgba(255,255,255,0.04)' }} contentStyle={tooltipStyle} />
              <Bar dataKey="value" radius={[8, 8, 0, 0]} barSize={36}>
                {a.areaDist.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Credit History" icon={CreditCard}>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={a.creditDist} dataKey="value" innerRadius={45} outerRadius={80} paddingAngle={3} stroke="none">
                <Cell fill="#14b8a6" /><Cell fill="#ef4444" />
              </Pie>
              <Tooltip contentStyle={tooltipStyle} /><Legend />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="section-grid-2" style={{ marginBottom: 18 }}>
        <ChartCard title="Income Distribution" icon={BarChart3} sub="total household income">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={a.incomeBuckets}>
              <XAxis dataKey="range" stroke="#6b7a96" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#6b7a96" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip cursor={{ fill: 'rgba(255,255,255,0.04)' }} contentStyle={tooltipStyle} />
              <Bar dataKey="count" radius={[8, 8, 0, 0]} fill="#2563eb" barSize={48} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Confidence Distribution" icon={Gauge}>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={a.confBuckets}>
              <XAxis dataKey="range" stroke="#6b7a96" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#6b7a96" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip cursor={{ fill: 'rgba(255,255,255,0.04)' }} contentStyle={tooltipStyle} />
              <Bar dataKey="count" radius={[8, 8, 0, 0]} fill="#14b8a6" barSize={48} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <ChartCard title="Feature Importance" icon={BarChart3} sub="model-wide">
        <ResponsiveContainer width="100%" height={360}>
          <BarChart data={global} layout="vertical" margin={{ left: 40 }}>
            <XAxis type="number" stroke="#6b7a96" fontSize={11} tickLine={false} axisLine={false} />
            <YAxis dataKey="label" type="category" stroke="#aebbd0" fontSize={11} width={140} tickLine={false} axisLine={false} />
            <Tooltip cursor={{ fill: 'rgba(255,255,255,0.04)' }} contentStyle={tooltipStyle} />
            <Bar dataKey="importance" radius={[0, 8, 8, 0]} barSize={18} fill="#8b5cf6" />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  )
}
