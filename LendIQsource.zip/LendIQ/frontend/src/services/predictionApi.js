// ============================================================
// predictionApi.js
// Prediction transport layer. When VITE_API_BASE_URL is set,
// LendIQ calls the FastAPI XGBoost+SHAP service (authenticated
// with an API key). Otherwise it uses the in-browser Edge Engine.
// Both return the SAME normalised prediction shape.
// ============================================================
import { scoreApplicant, scoreBatch } from '../engine/scoringEngine'

const API_BASE = import.meta.env.VITE_API_BASE_URL?.replace(/\/$/, '') || ''
const API_KEY = import.meta.env.VITE_API_KEY || ''

export const apiEnabled = Boolean(API_BASE)

function headers() {
  const h = { 'Content-Type': 'application/json' }
  if (API_KEY) h['X-API-Key'] = API_KEY
  return h
}

/** Map a FastAPI response onto the same shape the UI expects. */
function normalizeApiResult(raw, input) {
  return {
    id: input.Loan_ID || raw.loan_id || 'LP-API',
    engine: 'FastAPI Service',
    model: raw.model || 'XGBoost Classifier',
    prediction: raw.approved ? 'Approved' : 'Rejected',
    approved: raw.approved,
    approvalProbability: raw.approval_probability,
    rejectionProbability: raw.rejection_probability,
    confidence: raw.confidence,
    riskScore: raw.risk_score,
    riskLevel: raw.risk_level,
    baseValue: raw.base_value,
    logit: raw.logit ?? 0,
    contributions: raw.contributions || [],
    topPositive: (raw.contributions || []).filter((c) => c.contribution > 0).slice(0, 5),
    topNegative: (raw.contributions || []).filter((c) => c.contribution < 0).slice(0, 5),
    features: raw.features || {},
    derived: raw.derived || {},
    input,
    timestamp: new Date().toISOString(),
  }
}

async function callApi(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify(body),
  })
  if (!res.ok) {
    const msg = await res.text().catch(() => '')
    throw new Error(`Prediction service error (${res.status}): ${msg || res.statusText}`)
  }
  return res.json()
}

/**
 * Predict a single applicant. Tries the API (if configured) and
 * transparently falls back to the Edge Engine on any failure.
 */
export async function predictOne(raw) {
  if (apiEnabled) {
    try {
      const data = await callApi('/predict', raw)
      return normalizeApiResult(data, raw)
    } catch (err) {
      console.warn('[LendIQ] API predict failed, using Edge Engine:', err.message)
    }
  }
  return scoreApplicant(raw)
}

/** Predict a batch of applicants. */
export async function predictBatch(rows) {
  if (apiEnabled) {
    try {
      const data = await callApi('/predict/batch', { rows })
      return (data.results || []).map((r, i) => normalizeApiResult(r, rows[i]))
    } catch (err) {
      console.warn('[LendIQ] API batch failed, using Edge Engine:', err.message)
    }
  }
  return scoreBatch(rows)
}

/** Health probe for the Settings page. */
export async function apiHealth() {
  if (!apiEnabled) return { enabled: false, ok: false }
  try {
    const res = await fetch(`${API_BASE}/health`, { headers: headers() })
    return { enabled: true, ok: res.ok }
  } catch {
    return { enabled: true, ok: false }
  }
}
