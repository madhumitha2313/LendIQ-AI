import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import { ToastProvider } from './context/ToastContext'
import { ThemeProvider } from './context/ThemeContext'
import { PredictionProvider } from './context/PredictionContext'

import Backdrop from './components/ui/Backdrop'
import Layout from './components/layout/Layout'
import Splash from './pages/Splash'
import Login from './pages/Login'
import ForgotPassword from './pages/ForgotPassword'
import Dashboard from './pages/Dashboard'
import BatchPrediction from './pages/BatchPrediction'
import ManualPrediction from './pages/ManualPrediction'
import ExplainAI from './pages/ExplainAI'
import Analytics from './pages/Analytics'
import History from './pages/History'
import Reports from './pages/Reports'
import Settings from './pages/Settings'

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth()
  const location = useLocation()
  if (loading) return <Backdrop />
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />
  return children
}

function PublicOnly({ children }) {
  const { user, loading } = useAuth()
  if (loading) return <Backdrop />
  if (user) return <Navigate to="/dashboard" replace />
  return children
}

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <PredictionProvider>
            <Backdrop />
            <Routes>
              <Route path="/" element={<Splash />} />
              <Route path="/login" element={<PublicOnly><Login /></PublicOnly>} />
              <Route path="/forgot-password" element={<PublicOnly><ForgotPassword /></PublicOnly>} />

              <Route
                element={
                  <ProtectedRoute>
                    <Layout />
                  </ProtectedRoute>
                }
              >
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/batch" element={<BatchPrediction />} />
                <Route path="/manual" element={<ManualPrediction />} />
                <Route path="/explain" element={<ExplainAI />} />
                <Route path="/analytics" element={<Analytics />} />
                <Route path="/history" element={<History />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/settings" element={<Settings />} />
              </Route>

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </PredictionProvider>
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  )
}
