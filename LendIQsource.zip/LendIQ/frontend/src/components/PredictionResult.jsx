// ============================================================
// PredictionResult — the full decision card.
// Banner + KPIs + risk gauge + probability bars + SHAP local
// explanation + AI Loan Advisor + one-click exports.
// ============================================================
import {
  CheckCircle2, XCircle, TrendingUp, ShieldAlert, Clock, Lightbulb,
  FileDown, FileSpreadsheet, FileText, Sparkles,
} from 'lucide-react'
import RiskGauge from './ui/RiskGauge'
import Tilt from './ui/Tilt'
import ProbabilityBar from './ui/ProbabilityBar'
import ShapBars from './charts/ShapBars'
import { buildAdvisory } from '../engine/recommendationEngine'
import { exportPredictionPDF, exportCSV, exportExcel } from '../services/exportService'
import { useToast } from '../context/ToastContext'

export default function PredictionResult({ pred, showExports = true }) {
  const toast = useToast()
  if (!pred) return null
  const ok = pred.approved
  const advisory = buildAdvisory(pred)
  const accent = ok ? '#22c55e' : '#ef4444'
  const riskColor = pred.riskLevel === 'LOW' ? '#22c55e' : pred.riskLevel === 'MEDIUM' ? '#f59e0b' : '#ef4444'

  const doExport = (fn, label) => {
    try {
      fn()
      toast.success(`${label} exported`)
    } catch (e) {
      toast.error(`Export failed: ${e.message}`)
    }
  }

  return (
    <div className="grid" style={{ gap: 18 }}>
      {/* Banner */}
      <Tilt className="result-banner glass" max={4} scale={1.005} style={{ boxShadow: `inset 0 0 0 1px ${accent}33` }}>
        <div className="rb-ic tilt-pop" style={{ background: `${accent}22`, color: accent }}>
          {ok ? <CheckCircle2 size={30} /> : <XCircle size={30} />}
        </div>
        <div style={{ flex: 1 }} className="tilt-pop-sm">
          <div style={{ fontSize: 22, fontWeight: 800 }}>
            {ok ? 'Loan Approved' : 'Loan Rejected'}
          </div>
          <div className="text-dim" style={{ fontSize: 13.5 }}>
            Applicant <span className="mono">{pred.id}</span> · {pred.model}
          </div>
        </div>
        <div className="badge" style={{ background: `${accent}1f`, color: accent, borderColor: `${accent}44` }}>
          {pred.confidence}% confidence
        </div>
      </Tilt>

      {/* KPIs */}
      <div className="section-grid-3">
        <div className="kpi-pill">
          <div className="flex items-center gap-sm text-faint" style={{ fontSize: 12 }}><TrendingUp size={14} /> Approval Probability</div>
          <div className="v" style={{ color: '#22c55e' }}>{pred.approvalProbability}%</div>
          <ProbabilityBar value={pred.approvalProbability} color="#22c55e" height={8} />
        </div>
        <div className="kpi-pill">
          <div className="flex items-center gap-sm text-faint" style={{ fontSize: 12 }}><XCircle size={14} /> Rejection Probability</div>
          <div className="v" style={{ color: '#ef4444' }}>{pred.rejectionProbability}%</div>
          <ProbabilityBar value={pred.rejectionProbability} color="#ef4444" height={8} />
        </div>
        <div className="kpi-pill">
          <div className="flex items-center gap-sm text-faint" style={{ fontSize: 12 }}><Clock size={14} /> Decision Time</div>
          <div className="v" style={{ fontSize: 16 }}>{new Date(pred.timestamp).toLocaleString()}</div>
          <div style={{ fontSize: 11.5, color: 'var(--text-faint)' }}>Engine: {pred.engine}</div>
        </div>
      </div>

      <div className="section-grid-2">
        {/* Risk intelligence */}
        <div className="card glass">
          <div className="card-head">
            <h3 className="flex items-center gap-sm"><ShieldAlert size={17} /> Risk Intelligence</h3>
          </div>
          <RiskGauge score={pred.riskScore} level={pred.riskLevel} color={riskColor} />
          <div style={{ marginTop: 14 }}>
            {(pred.derived?.emiToIncome != null) && (
              <div className="flex justify-between" style={{ fontSize: 13, padding: '6px 0', borderBottom: '1px solid var(--stroke)' }}>
                <span className="text-dim">EMI / Income</span>
                <span className="mono">{pred.derived.emiToIncome}%</span>
              </div>
            )}
            {(pred.derived?.loanToIncome != null) && (
              <div className="flex justify-between" style={{ fontSize: 13, padding: '6px 0', borderBottom: '1px solid var(--stroke)' }}>
                <span className="text-dim">Loan / Annual Income</span>
                <span className="mono">{pred.derived.loanToIncome}×</span>
              </div>
            )}
            {(pred.derived?.totalIncome != null) && (
              <div className="flex justify-between" style={{ fontSize: 13, padding: '6px 0' }}>
                <span className="text-dim">Total Monthly Income</span>
                <span className="mono">₹{Number(pred.derived.totalIncome).toLocaleString()}</span>
              </div>
            )}
          </div>
        </div>

        {/* SHAP local explanation */}
        <div className="card glass">
          <div className="card-head">
            <h3 className="flex items-center gap-sm"><Sparkles size={17} /> Why This Decision (SHAP)</h3>
            <span className="sub">local explanation</span>
          </div>
          <ShapBars contributions={pred.contributions} max={8} />
          <div className="flex gap-sm" style={{ marginTop: 12, fontSize: 11.5 }}>
            <span className="badge badge-success">▶ supports approval</span>
            <span className="badge badge-danger">◀ supports rejection</span>
          </div>
        </div>
      </div>

      {/* AI Loan Advisor */}
      <div className="card glass" style={{ borderColor: `${accent}33` }}>
        <div className="card-head">
          <h3 className="flex items-center gap-sm"><Lightbulb size={17} color={accent} /> AI Loan Advisor</h3>
          <span className="badge" style={{ background: `${accent}1f`, color: accent, borderColor: `${accent}44` }}>
            {ok ? 'Qualified' : 'Action needed'}
          </span>
        </div>
        <p style={{ fontSize: 14, lineHeight: 1.6, color: 'var(--text-dim)', marginBottom: 16 }}>{advisory.summary}</p>
        <div className="section-grid-2">
          <div>
            <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text-faint)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 9 }}>
              {ok ? 'Why it qualifies' : 'Primary reasons'}
            </div>
            <ul style={{ listStyle: 'none', display: 'grid', gap: 8 }}>
              {advisory.reasons.map((r, i) => (
                <li key={i} className="flex items-center gap-sm" style={{ fontSize: 13.5 }}>
                  <span style={{ width: 7, height: 7, borderRadius: '50%', background: accent, flexShrink: 0 }} />
                  {r}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text-faint)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 9 }}>
              Recommended actions
            </div>
            <ul style={{ listStyle: 'none', display: 'grid', gap: 8 }}>
              {advisory.actions.map((r, i) => (
                <li key={i} className="flex gap-sm" style={{ fontSize: 13.5, alignItems: 'flex-start' }}>
                  <Lightbulb size={14} style={{ color: 'var(--warning)', marginTop: 2, flexShrink: 0 }} />
                  {r}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Exports */}
      {showExports && (
        <div className="card glass flex items-center justify-between" style={{ flexWrap: 'wrap', gap: 12 }}>
          <div className="flex items-center gap-sm">
            <FileDown size={18} color="var(--primary-soft)" />
            <div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Export this decision</div>
              <div style={{ fontSize: 12, color: 'var(--text-faint)' }}>Includes SHAP summary + AI recommendation</div>
            </div>
          </div>
          <div className="flex gap-sm" style={{ flexWrap: 'wrap' }}>
            <button className="btn btn-primary btn-sm" onClick={() => doExport(() => exportPredictionPDF(pred), 'PDF report')}>
              <FileText size={15} /> PDF
            </button>
            <button className="btn btn-ghost btn-sm" onClick={() => doExport(() => exportExcel(pred, `LendIQ-${pred.id}.xlsx`), 'Excel')}>
              <FileSpreadsheet size={15} /> Excel
            </button>
            <button className="btn btn-ghost btn-sm" onClick={() => doExport(() => exportCSV(pred, `LendIQ-${pred.id}.csv`), 'CSV')}>
              <FileDown size={15} /> CSV
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
