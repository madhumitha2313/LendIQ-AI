import { useState, useRef } from 'react'
import { SlidersHorizontal, Sparkles, RotateCcw, User, Wallet } from 'lucide-react'
import PredictionResult from '../components/PredictionResult'
import { predictOne } from '../services/predictionApi'
import { savePrediction } from '../services/historyService'
import { usePrediction } from '../context/PredictionContext'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

const EMPTY = {
  Loan_ID: '',
  Gender: 'Male',
  Married: 'Yes',
  Dependents: '0',
  Education: 'Graduate',
  Self_Employed: 'No',
  ApplicantIncome: '',
  CoapplicantIncome: '0',
  LoanAmount: '',
  Loan_Amount_Term: '360',
  Credit_History: '1',
  Property_Area: 'Semiurban',
}

const SELECTS = {
  Gender: ['Male', 'Female'],
  Married: ['Yes', 'No'],
  Dependents: ['0', '1', '2', '3+'],
  Education: ['Graduate', 'Not Graduate'],
  Self_Employed: ['No', 'Yes'],
  Credit_History: [['1', 'Good (1)'], ['0', 'Poor / None (0)']],
  Property_Area: ['Urban', 'Semiurban', 'Rural'],
}

export default function ManualPrediction() {
  const [form, setForm] = useState(EMPTY)
  const [busy, setBusy] = useState(false)
  const { lastPrediction, setLastPrediction, refreshHistory } = usePrediction()
  const { user } = useAuth()
  const toast = useToast()
  const resultRef = useRef(null)

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }))

  const validate = () => {
    if (!form.ApplicantIncome || Number(form.ApplicantIncome) <= 0) return 'Applicant income must be greater than 0'
    if (!form.LoanAmount || Number(form.LoanAmount) <= 0) return 'Loan amount must be greater than 0'
    if (Number(form.Loan_Amount_Term) <= 0) return 'Loan term must be greater than 0'
    return null
  }

  const submit = async (e) => {
    e.preventDefault()
    const err = validate()
    if (err) return toast.error(err)
    setBusy(true)
    try {
      const payload = {
        ...form,
        Loan_ID: form.Loan_ID || `LP-${Date.now().toString().slice(-6)}`,
        ApplicantIncome: Number(form.ApplicantIncome),
        CoapplicantIncome: Number(form.CoapplicantIncome || 0),
        LoanAmount: Number(form.LoanAmount),
        Loan_Amount_Term: Number(form.Loan_Amount_Term),
        Credit_History: Number(form.Credit_History),
      }
      const pred = await predictOne(payload)
      setLastPrediction(pred)
      if (user) {
        await savePrediction(pred, user.uid, 'manual')
        await refreshHistory()
      }
      toast.success(`Decision ready: ${pred.prediction}`)
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80)
    } catch (err) {
      toast.error(err.message || 'Prediction failed')
    } finally {
      setBusy(false)
    }
  }

  const renderSelect = (key, label) => {
    const opts = SELECTS[key]
    return (
      <div className="field" key={key}>
        <label>{label}</label>
        <select className="select" value={form[key]} onChange={(e) => set(key, e.target.value)}>
          {opts.map((o) => Array.isArray(o)
            ? <option key={o[0]} value={o[0]}>{o[1]}</option>
            : <option key={o} value={o}>{o}</option>)}
        </select>
      </div>
    )
  }

  return (
    <div className="page">
      <div style={{ marginBottom: 22 }}>
        <h1 className="page-title flex items-center gap-sm"><SlidersHorizontal size={24} /> Manual Prediction</h1>
        <p className="page-sub">Enter applicant details for an instant explainable decision.</p>
      </div>

      <form onSubmit={submit} className="card glass" style={{ marginBottom: 22 }}>
        <div className="card-head">
          <h3 className="flex items-center gap-sm"><User size={17} /> Applicant Profile</h3>
          <span className="sub">all fields validated</span>
        </div>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(190px,1fr))', gap: 16 }}>
          <div className="field">
            <label>Loan ID (optional)</label>
            <input className="input" placeholder="auto-generated" value={form.Loan_ID} onChange={(e) => set('Loan_ID', e.target.value)} />
          </div>
          {renderSelect('Gender', 'Gender')}
          {renderSelect('Married', 'Married')}
          {renderSelect('Dependents', 'Dependents')}
          {renderSelect('Education', 'Education')}
          {renderSelect('Self_Employed', 'Self Employed')}
          {renderSelect('Property_Area', 'Property Area')}
          {renderSelect('Credit_History', 'Credit History')}
        </div>

        <div className="card-head" style={{ marginTop: 22 }}>
          <h3 className="flex items-center gap-sm"><Wallet size={17} /> Financials</h3>
        </div>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(190px,1fr))', gap: 16 }}>
          <div className="field">
            <label>Applicant Income (₹ / month)</label>
            <input className="input" type="number" min="0" placeholder="5000" value={form.ApplicantIncome} onChange={(e) => set('ApplicantIncome', e.target.value)} />
          </div>
          <div className="field">
            <label>Coapplicant Income (₹ / month)</label>
            <input className="input" type="number" min="0" placeholder="0" value={form.CoapplicantIncome} onChange={(e) => set('CoapplicantIncome', e.target.value)} />
          </div>
          <div className="field">
            <label>Loan Amount (₹ thousands)</label>
            <input className="input" type="number" min="0" placeholder="120" value={form.LoanAmount} onChange={(e) => set('LoanAmount', e.target.value)} />
          </div>
          <div className="field">
            <label>Loan Term (months)</label>
            <input className="input" type="number" min="0" placeholder="360" value={form.Loan_Amount_Term} onChange={(e) => set('Loan_Amount_Term', e.target.value)} />
          </div>
        </div>

        <div className="flex gap-sm" style={{ marginTop: 24 }}>
          <button className="btn btn-primary" type="submit" disabled={busy}>
            {busy ? <span className="spinner" /> : <><Sparkles size={16} /> Predict Decision</>}
          </button>
          <button className="btn btn-ghost" type="button" onClick={() => setForm(EMPTY)}>
            <RotateCcw size={15} /> Reset
          </button>
        </div>
      </form>

      <div ref={resultRef}>
        {lastPrediction ? (
          <PredictionResult pred={lastPrediction} />
        ) : (
          <div className="card glass empty-state">
            <div className="ic"><Sparkles size={26} /></div>
            Fill in the applicant profile and run a prediction to see the explainable decision, risk gauge and AI recommendations here.
          </div>
        )}
      </div>
    </div>
  )
}
