// ============================================================
// riskEngine.js
// Translates a prediction into risk-intelligence primitives:
// a 0–100 score, a LOW/MEDIUM/HIGH band, colour, and the data
// needed to drive the animated gauge.
// ============================================================

export const RISK_BANDS = [
  { level: 'LOW', max: 33, color: '#22c55e', label: 'Low Risk' },
  { level: 'MEDIUM', max: 66, color: '#f59e0b', label: 'Moderate Risk' },
  { level: 'HIGH', max: 100, color: '#ef4444', label: 'High Risk' },
]

export function riskFromPrediction(pred) {
  const score = pred.riskScore
  const band = RISK_BANDS.find((b) => score <= b.max) || RISK_BANDS[2]

  // Decompose risk drivers for the risk card.
  const drivers = []
  if (pred.input.Credit_History === 0) drivers.push('No / poor credit history')
  if (pred.derived.emiToIncome > 12) drivers.push('High EMI-to-income ratio')
  if (pred.derived.loanToIncome > 3) drivers.push('Large loan relative to income')
  if (pred.input.Dependents >= 3) drivers.push('High number of dependents')
  if (pred.derived.totalIncome < 3000) drivers.push('Low household income')
  if (!drivers.length) drivers.push('No significant risk drivers identified')

  return {
    score,
    level: band.level,
    label: band.label,
    color: band.color,
    drivers,
    // gauge geometry: 0–100 mapped onto a 180° arc
    angle: -90 + (score / 100) * 180,
  }
}

/** A compact portfolio-level risk summary for a batch of predictions. */
export function portfolioRisk(predictions = []) {
  if (!predictions.length) return { avg: 0, level: 'LOW', high: 0, medium: 0, low: 0 }
  const counts = { LOW: 0, MEDIUM: 0, HIGH: 0 }
  let sum = 0
  predictions.forEach((p) => {
    sum += p.riskScore
    counts[p.riskLevel] = (counts[p.riskLevel] || 0) + 1
  })
  const avg = sum / predictions.length
  const level = avg < 33 ? 'LOW' : avg < 66 ? 'MEDIUM' : 'HIGH'
  return { avg: Number(avg.toFixed(1)), level, high: counts.HIGH, medium: counts.MEDIUM, low: counts.LOW }
}
