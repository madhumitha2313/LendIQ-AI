import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Mail, ArrowLeft, MailCheck } from 'lucide-react'
import Logo from '../components/ui/Logo'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [busy, setBusy] = useState(false)
  const [sent, setSent] = useState(false)
  const { resetPassword } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    if (!email) return toast.error('Please enter your email')
    setBusy(true)
    try {
      await resetPassword(email)
      setSent(true)
      toast.success('Password reset email sent')
    } catch (err) {
      toast.error(err.message || 'Could not send reset email')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="auth-panel" style={{ minHeight: '100vh' }}>
      <div className="auth-card glass glass-strong">
        <Logo size={44} withText />
        {!sent ? (
          <>
            <div style={{ margin: '22px 0' }}>
              <h2>Reset your password</h2>
              <p className="text-dim" style={{ fontSize: 13.5, marginTop: 6 }}>
                Enter the email linked to your account and we'll send you a secure reset link.
              </p>
            </div>
            <form onSubmit={submit} className="grid" style={{ gap: 16 }}>
              <div className="field">
                <label>Email address</label>
                <div className="auth-input-wrap">
                  <input className="input" style={{ paddingLeft: 40 }} type="email" placeholder="you@company.com" value={email} onChange={(e) => setEmail(e.target.value)} />
                  <Mail size={16} style={{ position: 'absolute', left: 14, top: 14, color: 'var(--text-faint)' }} />
                </div>
              </div>
              <button className="btn btn-primary btn-block" disabled={busy} type="submit">
                {busy ? <span className="spinner" /> : 'Send reset link'}
              </button>
            </form>
          </>
        ) : (
          <div style={{ textAlign: 'center', padding: '24px 0' }}>
            <div style={{ width: 64, height: 64, borderRadius: 18, margin: '0 auto 16px', display: 'grid', placeItems: 'center', background: 'rgba(34,197,94,0.15)', color: '#22c55e' }}>
              <MailCheck size={30} />
            </div>
            <h2 style={{ fontSize: 20 }}>Check your inbox</h2>
            <p className="text-dim" style={{ fontSize: 13.5, marginTop: 8 }}>
              If an account exists for <strong style={{ color: 'var(--text)' }}>{email}</strong>, a reset link is on its way.
            </p>
          </div>
        )}
        <button onClick={() => navigate('/login')} className="flex items-center gap-sm" style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', marginTop: 22, fontSize: 13.5, fontWeight: 600 }}>
          <ArrowLeft size={15} /> Back to sign in
        </button>
      </div>
    </div>
  )
}
