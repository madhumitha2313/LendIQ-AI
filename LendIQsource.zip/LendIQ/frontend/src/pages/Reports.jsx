import { useNavigate } from 'react-router-dom'
import {
  FileBarChart, FileText, FileSpreadsheet, FileDown, CheckCircle2, Layers,
  User, ShieldAlert, Sparkles, Database,
} from 'lucide-react'
import {
  exportPredictionPDF, exportBatchPDF, exportExcel, exportCSV,
} from '../services/exportService'
import { scoreApplicant } from '../engine/scoringEngine'
import { usePrediction } from '../context/PredictionContext'
import { useToast } from '../context/ToastContext'

const INCLUDES = [
  { icon: User, t: 'Applicant Details' },
  { icon: CheckCircle2, t: 'Prediction & Confidence' },
  { icon: ShieldAlert, t: 'Risk Score' },
  { icon: Sparkles, t: 'SHAP Summary' },
  { icon: FileText, t: 'AI Recommendation' },
  { icon: Database, t: 'Model & Timestamp' },
]

function ReportCard({ title, subtitle, disabled, onPDF, onExcel, onCSV, accent = '#2563eb', emptyHint }) {
  return (
    <div className="card glass" style={{ borderColor: `${accent}33` }}>
      <div className="card-head">
        <h3 className="flex items-center gap-sm">{title}</h3>
      </div>
      <p className="text-dim" style={{ fontSize: 13.5, marginBottom: 14 }}>{subtitle}</p>
      {disabled ? (
        <div className="text-faint" style={{ fontSize: 13, padding: '10px 0' }}>{emptyHint}</div>
      ) : (
        <div className="flex gap-sm" style={{ flexWrap: 'wrap' }}>
          {onPDF && <button className="btn btn-primary btn-sm" onClick={onPDF}><FileText size={14} /> PDF</button>}
          {onExcel && <button className="btn btn-ghost btn-sm" onClick={onExcel}><FileSpreadsheet size={14} /> Excel</button>}
          {onCSV && <button className="btn btn-ghost btn-sm" onClick={onCSV}><FileDown size={14} /> CSV</button>}
        </div>
      )}
    </div>
  )
}

export default function Reports() {
  const { lastPrediction, batchResults, history } = usePrediction()
  const toast = useToast()
  const navigate = useNavigate()

  const historyPreds = () =>
    history.map((r) => (r.snapshot?.input ? scoreApplicant(r.snapshot.input) : null)).filter(Boolean)

  const guard = (fn, label) => () => {
    try { fn(); toast.success(`${label} generated`) } catch (e) { toast.error(e.message) }
  }

  return (
    <div className="page">
      <div style={{ marginBottom: 22 }}>
        <h1 className="page-title flex items-center gap-sm"><FileBarChart size={24} /> Reports</h1>
        <p className="page-sub">Generate audit-ready PDF, Excel and CSV reports — SHAP + AI recommendations included.</p>
      </div>

      {/* What's included */}
      <div className="card glass" style={{ marginBottom: 18 }}>
        <div className="card-head"><h3>Every report includes</h3></div>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 12 }}>
          {INCLUDES.map((i) => (
            <div key={i.t} className="flex items-center gap-sm" style={{ padding: '10px 12px', borderRadius: 12, background: 'var(--card)', border: '1px solid var(--stroke)' }}>
              <i.icon size={16} color="#5eead4" />
              <span style={{ fontSize: 13 }}>{i.t}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="section-grid-2" style={{ marginBottom: 18 }}>
        <ReportCard
          title={<><FileText size={17} /> Latest Decision Report</>}
          subtitle={lastPrediction ? `Detailed single-applicant report for ${lastPrediction.id}.` : 'Run a prediction to generate a detailed decision report.'}
          accent="#22c55e"
          disabled={!lastPrediction}
          emptyHint="No recent prediction. Make one from Manual or Batch Prediction."
          onPDF={lastPrediction ? guard(() => exportPredictionPDF(lastPrediction), 'PDF report') : null}
          onExcel={lastPrediction ? guard(() => exportExcel(lastPrediction, `LendIQ-${lastPrediction.id}.xlsx`), 'Excel report') : null}
          onCSV={lastPrediction ? guard(() => exportCSV(lastPrediction, `LendIQ-${lastPrediction.id}.csv`), 'CSV report') : null}
        />

        <ReportCard
          title={<><Layers size={17} /> Batch Report</>}
          subtitle={batchResults?.length ? `Summary report for ${batchResults.length} scored applicants.` : 'Score a dataset in Batch Prediction to enable batch reports.'}
          accent="#2563eb"
          disabled={!batchResults?.length}
          emptyHint="No batch results in this session."
          onPDF={batchResults?.length ? guard(() => exportBatchPDF(batchResults), 'Batch PDF') : null}
          onExcel={batchResults?.length ? guard(() => exportExcel(batchResults, 'lendiq-batch.xlsx'), 'Batch Excel') : null}
          onCSV={batchResults?.length ? guard(() => exportCSV(batchResults, 'lendiq-batch.csv'), 'Batch CSV') : null}
        />
      </div>

      <ReportCard
        title={<><Database size={17} /> Portfolio Report</>}
        subtitle={history.length ? `Full portfolio export across ${history.length} stored predictions.` : 'Your saved prediction history will be exportable here.'}
        accent="#8b5cf6"
        disabled={!history.length}
        emptyHint="No prediction history yet."
        onExcel={history.length ? guard(() => exportExcel(historyPreds(), 'lendiq-portfolio.xlsx'), 'Portfolio Excel') : null}
        onCSV={history.length ? guard(() => exportCSV(historyPreds(), 'lendiq-portfolio.csv'), 'Portfolio CSV') : null}
      />

      {!lastPrediction && !batchResults?.length && !history.length && (
        <div className="card glass empty-state" style={{ marginTop: 18 }}>
          <div className="ic"><FileBarChart size={26} /></div>
          Make your first prediction to start generating reports.
          <div style={{ marginTop: 14 }}>
            <button className="btn btn-primary btn-sm" onClick={() => navigate('/manual')}>Make a prediction</button>
          </div>
        </div>
      )}
    </div>
  )
}
