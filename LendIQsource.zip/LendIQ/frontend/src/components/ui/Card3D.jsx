// Floating 3D glass "credit card" used on the auth hero.
import { Wifi } from 'lucide-react'

export default function Card3D() {
  return (
    <div className="scene-3d">
      <div className="card3d">
        <div className="flex justify-between items-center" style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ fontWeight: 800, fontSize: 20, letterSpacing: '-0.02em' }}>
            Lend<span style={{ color: '#bbf7d0' }}>IQ</span>
          </div>
          <Wifi size={20} style={{ transform: 'rotate(90deg)', opacity: 0.85 }} />
        </div>
        <div className="chip" style={{ marginTop: 26, position: 'relative', zIndex: 1 }} />
        <div className="c-num" style={{ marginTop: 16, position: 'relative', zIndex: 1 }}>
          4821&nbsp;&nbsp;88•• &nbsp;&nbsp;••62 &nbsp;&nbsp;0142
        </div>
        <div className="flex justify-between" style={{ marginTop: 14, position: 'relative', zIndex: 1, fontSize: 11, opacity: 0.9 }}>
          <div>
            <div style={{ opacity: 0.7, fontSize: 9 }}>CARDHOLDER</div>
            <div style={{ fontWeight: 600 }}>EXPLAINABLE AI</div>
          </div>
          <div>
            <div style={{ opacity: 0.7, fontSize: 9 }}>MODEL</div>
            <div style={{ fontWeight: 600 }}>XGBOOST · 88.62%</div>
          </div>
        </div>
      </div>
    </div>
  )
}
