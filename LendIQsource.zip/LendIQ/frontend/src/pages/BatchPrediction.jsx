import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Layers, UploadCloud, FileSpreadsheet, Download, Sparkles, CheckCircle2,
  XCircle, FileText, FileDown, Eye, Trash2,
} from 'lucide-react'
import { parseFile, SAMPLE_ROWS } from '../services/fileParser'
import { validateColumns } from '../engine/preprocessing'
import { predictBatch } from '../services/predictionApi'
import { savePredictions } from '../services/historyService'
import { exportBatchPDF, exportCSV, exportExcel, exportPredictionPDF } from '../services/exportService'
import { portfolioRisk } from '../engine/riskEngine'
import { usePrediction } from '../context/PredictionContext'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

export default function BatchPrediction() {
  const [file, setFile] = useState(null)
  const [drag, setDrag] = useState(false)
  const [busy, setBusy] = useState(false)
  const inputRef = useRef(null)
  const navigate = useNavigate()
  const { batchResults, setBatchResults, setLastPrediction, refreshHistory } = usePrediction()
  const { user } = useAuth()
  const toast = useToast()

  const results = batchResults || []
  const summary = results.length
    ? {
        total: results.length,
        approved: results.filter((r) => r.approved).length,
        rejected: results.filter((r) => !r.approved).length,
        avgConf: (results.reduce((s, r) => s + r.confidence, 0) / results.length).toFixed(1),
        risk: portfolioRisk(results),
      }
    : null

  const handleFiles = (f) => {
    if (!f) return
    const ok = /\.(csv|xlsx|xls)$/i.test(f.name)
    if (!ok) return toast.error('Please upload a .csv or .xlsx file')
    setFile(f)
  }

  const process = async () => {
    if (!file) return toast.error('Choose a file first')
    setBusy(true)
    try {
      const { rows, headers } = await parseFile(file)
      const check = validateColumns(headers)
      if (!check.ok) {
        toast.error(`Missing required columns: ${check.missing.join(', ')}`)
        setBusy(false)
        return
      }
      const preds = await predictBatch(rows)
      setBatchResults(preds)
      if (user) {
        await savePredictions(preds, user.uid, 'batch')
        await refreshHistory()
      }
      toast.success(`Scored ${preds.length} applicants`)
    } catch (err) {
      toast.error(err.message || 'Could not process file')
    } finally {
      setBusy(false)
    }
  }

  const downloadTemplate = () => {
    const headers = Object.keys(SAMPLE_ROWS[0])
    const csv = [headers.join(','), ...SAMPLE_ROWS.map((r) => headers.map((h) => r[h]).join(','))].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'lendiq-template.csv'
    a.click()
    setTimeout(() => URL.revokeObjectURL(a.href), 1500)
    toast.info('Sample template downloaded')
  }

  const viewDetail = (pred) => {
    setLastPrediction(pred)
    navigate('/explain')
  }

  return (
    <div className="page">
      <div className="flex justify-between items-center" style={{ flexWrap: 'wrap', gap: 12, marginBottom: 22 }}>
        <div>
          <h1 className="page-title flex items-center gap-sm"><Layers size={24} /> Batch Prediction</h1>
          <p className="page-sub">Upload an applicant dataset for bulk explainable scoring.</p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={downloadTemplate}>
          <Download size={15} /> Download template
        </button>
      </div>

      {/* Upload */}
      <div className="card glass" style={{ marginBottom: 18 }}>
        <div
          className={`dropzone ${drag ? 'drag' : ''}`}
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDrag(true) }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); handleFiles(e.dataTransfer.files?.[0]) }}
        >
          <input ref={inputRef} type="file" accept=".csv,.xlsx,.xls" hidden onChange={(e) => handleFiles(e.target.files?.[0])} />
          <div style={{ width: 56, height: 56, borderRadius: 16, margin: '0 auto 14px', display: 'grid', placeItems: 'center', background: 'rgba(37,99,235,0.16)', color: '#3b82f6' }}>
            <UploadCloud size={28} />
          </div>
          {file ? (
            <>
              <div style={{ fontWeight: 700, fontSize: 15 }}>{file.name}</div>
              <div className="text-faint" style={{ fontSize: 12.5, marginTop: 4 }}>{(file.size / 1024).toFixed(1)} KB · click to replace</div>
            </>
          ) : (
            <>
              <div style={{ fontWeight: 700, fontSize: 15 }}>Drop your .xlsx or .csv here</div>
              <div className="text-faint" style={{ fontSize: 12.5, marginTop: 4 }}>or click to browse · expected loan-application columns</div>
            </>
          )}
        </div>
        <div className="flex gap-sm" style={{ marginTop: 16, flexWrap: 'wrap' }}>
          <button className="btn btn-primary" onClick={process} disabled={busy || !file}>
            {busy ? <span className="spinner" /> : <><Sparkles size={16} /> Run Batch Prediction</>}
          </button>
          {file && <button className="btn btn-ghost" onClick={() => setFile(null)}><Trash2 size={15} /> Clear</button>}
          {results.length > 0 && <button className="btn btn-ghost" onClick={() => setBatchResults([])}>Clear results</button>}
        </div>
        <div className="text-faint" style={{ fontSize: 12, marginTop: 12 }}>
          Pipeline: validate → clean → feature-engineer → encode → score (XGBoost / Edge Engine) → SHAP explain.
        </div>
      </div>

      {/* Summary */}
      {summary && (
        <>
          <div className="stat-grid" style={{ marginBottom: 18 }}>
            <div className="kpi-pill"><div className="l">Applicants</div><div className="v">{summary.total}</div></div>
            <div className="kpi-pill"><div className="l">Approved</div><div className="v" style={{ color: '#22c55e' }}>{summary.approved}</div></div>
            <div className="kpi-pill"><div className="l">Rejected</div><div className="v" style={{ color: '#ef4444' }}>{summary.rejected}</div></div>
            <div className="kpi-pill"><div className="l">Avg. Confidence</div><div className="v" style={{ color: '#5eead4' }}>{summary.avgConf}%</div></div>
            <div className="kpi-pill"><div className="l">Portfolio Risk</div><div className="v" style={{ color: summary.risk.level === 'LOW' ? '#22c55e' : summary.risk.level === 'MEDIUM' ? '#f59e0b' : '#ef4444' }}>{summary.risk.level}</div></div>
          </div>

          <div className="card glass">
            <div className="card-head">
              <h3>Results</h3>
              <div className="flex gap-sm" style={{ flexWrap: 'wrap' }}>
                <button className="btn btn-primary btn-sm" onClick={() => exportBatchPDF(results)}><FileText size={14} /> PDF</button>
                <button className="btn btn-ghost btn-sm" onClick={() => exportExcel(results, 'lendiq-batch.xlsx')}><FileSpreadsheet size={14} /> Excel</button>
                <button className="btn btn-ghost btn-sm" onClick={() => exportCSV(results, 'lendiq-batch.csv')}><FileDown size={14} /> CSV</button>
              </div>
            </div>
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Applicant</th><th>Decision</th><th>Confidence</th><th>Approval %</th>
                    <th>Rejection %</th><th>Risk</th><th>Reason</th><th></th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((r) => (
                    <tr key={r.id}>
                      <td className="mono">{r.id}</td>
                      <td>
                        <span className={`badge ${r.approved ? 'badge-success' : 'badge-danger'}`}>
                          {r.approved ? <CheckCircle2 size={12} /> : <XCircle size={12} />} {r.prediction}
                        </span>
                      </td>
                      <td>{r.confidence}%</td>
                      <td style={{ color: '#22c55e' }}>{r.approvalProbability}%</td>
                      <td style={{ color: '#ef4444' }}>{r.rejectionProbability}%</td>
                      <td><span className={`badge ${r.riskLevel === 'LOW' ? 'badge-success' : r.riskLevel === 'MEDIUM' ? 'badge-warn' : 'badge-danger'}`}>{r.riskScore}</span></td>
                      <td className="text-dim">{(r.approved ? r.topPositive?.[0]?.label : r.topNegative?.[0]?.label) || '—'}</td>
                      <td>
                        <div className="flex gap-sm">
                          <button className="icon-btn" style={{ width: 32, height: 32 }} title="Explain" onClick={() => viewDetail(r)}><Eye size={15} /></button>
                          <button className="icon-btn" style={{ width: 32, height: 32 }} title="PDF" onClick={() => exportPredictionPDF(r)}><FileText size={15} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {!summary && (
        <div className="card glass empty-state">
          <div className="ic"><FileSpreadsheet size={26} /></div>
          Upload a dataset to see bulk predictions, portfolio risk and one-click exports.
        </div>
      )}
    </div>
  )
}
