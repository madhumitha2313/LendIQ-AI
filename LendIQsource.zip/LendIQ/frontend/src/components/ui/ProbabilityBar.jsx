// Animated probability / confidence bar.
export default function ProbabilityBar({ value = 0, color = '#2563eb', height = 12 }) {
  return (
    <div className="prob-bar" style={{ height }}>
      <span
        style={{
          width: `${Math.max(0, Math.min(100, value))}%`,
          background: `linear-gradient(90deg, ${color}, ${color}cc)`,
        }}
      />
    </div>
  )
}
