"""
LendIQ — FastAPI prediction service.

Serves real XGBoost predictions with SHAP explanations. Protected by an
optional API key (set LENDIQ_API_KEY to require the `X-API-Key` header).
The response shape matches what the React frontend (predictionApi.js)
expects, so the UI works identically whether it calls this service or
its in-browser Edge Engine.

Run:  uvicorn main:app --reload --port 8000
"""
from __future__ import annotations

import os
import math
import pickle
from typing import List, Optional

import numpy as np
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from pipeline import (
    clean_row, engineer, to_feature_frame, risk_band,
    FEATURE_ORDER, FEATURE_LABELS,
)

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(HERE, "model", "best_xgb.pkl")
API_KEY = os.environ.get("LENDIQ_API_KEY", "")  # empty → auth disabled

app = FastAPI(title="LendIQ Prediction Service", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("LENDIQ_CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)

_state = {"model": None, "explainer": None, "feature_order": FEATURE_ORDER}


# ---------------------------------------------------------------- model load
def load_model():
    if not os.path.exists(MODEL_PATH):
        print("Model not found — training a fresh model…")
        import train_model
        train_model.main()
    with open(MODEL_PATH, "rb") as f:
        bundle = pickle.load(f)
    _state["model"] = bundle["model"]
    _state["feature_order"] = bundle.get("feature_order", FEATURE_ORDER)
    try:
        import shap
        _state["explainer"] = shap.TreeExplainer(bundle["model"])
        print("✓ SHAP TreeExplainer ready")
    except Exception as exc:  # noqa: BLE001
        print(f"⚠ SHAP unavailable ({exc}); contributions will be approximated.")
        _state["explainer"] = None


@app.on_event("startup")
def _startup():
    load_model()


# ---------------------------------------------------------------- schemas
class Applicant(BaseModel):
    Loan_ID: Optional[str] = None
    Gender: Optional[str] = "Male"
    Married: Optional[str] = "Yes"
    Dependents: Optional[str] = "0"
    Education: Optional[str] = "Graduate"
    Self_Employed: Optional[str] = "No"
    ApplicantIncome: float = 0
    CoapplicantIncome: float = 0
    LoanAmount: float = 0
    Loan_Amount_Term: float = 360
    Credit_History: float = 1
    Property_Area: Optional[str] = "Semiurban"


class BatchRequest(BaseModel):
    rows: List[Applicant]


# ---------------------------------------------------------------- helpers
def _require_key(x_api_key: Optional[str]):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


def _sigmoid(z: float) -> float:
    return 1.0 / (1.0 + math.exp(-z))


def _explain(features: dict):
    """Return (base_value_prob, [contributions]) using SHAP when available."""
    order = _state["feature_order"]
    row = np.array([[features[k] for k in order]], dtype=float)
    explainer = _state["explainer"]
    if explainer is not None:
        sv = explainer.shap_values(row)
        if isinstance(sv, list):  # some shap versions return per-class list
            sv = sv[-1]
        values = np.array(sv).reshape(-1)[: len(order)]
        base = explainer.expected_value
        if isinstance(base, (list, np.ndarray)):
            base = float(np.array(base).reshape(-1)[-1])
        base_prob = _sigmoid(float(base)) * 100
    else:
        # Fallback: contribution-free zeros with model base rate.
        values = np.zeros(len(order))
        base_prob = 50.0

    contributions = []
    for k, v in zip(order, values):
        contributions.append({
            "key": k,
            "label": FEATURE_LABELS.get(k, k),
            "value": round(float(features[k]), 3),
            "contribution": round(float(v), 4),
            "impact": "positive" if v >= 0 else "negative",
        })
    return round(base_prob, 2), contributions


def _predict_one(raw: dict) -> dict:
    clean = clean_row(raw)
    features, derived = engineer(clean)
    model = _state["model"]
    order = _state["feature_order"]
    X = np.array([[features[k] for k in order]], dtype=float)

    approval_prob = float(model.predict_proba(X)[0, 1])
    approved = approval_prob >= 0.5
    confidence = approval_prob if approved else 1 - approval_prob
    score, level = risk_band(approval_prob)
    base_prob, contributions = _explain(features)

    return {
        "loan_id": clean["Loan_ID"],
        "model": "XGBoost Classifier",
        "engine": "FastAPI Service",
        "approved": approved,
        "approval_probability": round(approval_prob * 100, 2),
        "rejection_probability": round((1 - approval_prob) * 100, 2),
        "confidence": round(confidence * 100, 2),
        "risk_score": score,
        "risk_level": level,
        "base_value": base_prob,
        "logit": 0,
        "contributions": contributions,
        "features": {k: round(float(v), 4) for k, v in features.items()},
        "derived": derived,
    }


# ---------------------------------------------------------------- routes
@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": _state["model"] is not None,
            "shap": _state["explainer"] is not None, "auth": bool(API_KEY)}


@app.post("/predict")
def predict(applicant: Applicant, x_api_key: Optional[str] = Header(default=None)):
    _require_key(x_api_key)
    return _predict_one(applicant.model_dump())


@app.post("/predict/batch")
def predict_batch(req: BatchRequest, x_api_key: Optional[str] = Header(default=None)):
    _require_key(x_api_key)
    results = [_predict_one(a.model_dump()) for a in req.rows]
    approved = sum(1 for r in results if r["approved"])
    return {
        "count": len(results),
        "approved": approved,
        "rejected": len(results) - approved,
        "results": results,
    }


@app.get("/")
def root():
    return {"service": "LendIQ Prediction Service", "docs": "/docs", "health": "/health"}
