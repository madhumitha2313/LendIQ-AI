import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Sparkles, BarChart3, GitBranch, TrendingUp, TrendingDown, Globe, Crosshair,
} from 'lucide-react'
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts'
import ShapBars from '../components/charts/ShapBars'
import ShapWaterfall from '../components/charts/ShapWaterfall'
import { globalImportance } from '../engine/scoringEngine'
import { usePrediction } from '../context/PredictionContext'

export default function ExplainAI() {
  const { lastPrediction } = usePrediction()
  const [tab, setTab] = useState('local')
  const navigate = useNavigate()
  const global = globalImportance()

  return (
    <div className="page">
      <div className="flex justify-between items-center" style={{ flexWrap: 'wrap', gap: 12, marginBottom: 22 }}>
        <div>
          <h1 className="page-title flex items-center gap-sm"><Sparkles size={24} /> Explainable AI</h1>
          <p className="page-sub">SHAP-powered transparency for every LendIQ decision.</p>
        </div>
        <div className="seg-tabs">
          <button className={`seg-tab ${tab === 'local' ? 'active' : ''}`} onClick={() => setTab('local')}>
            <Crosshair size={13} style={{ marginRight: 5 }} /> Local
          </button>
          <button className={`seg-tab ${tab === 'global' ? 'active' : ''}`} onClick={() => setTab('global')}>
            <Globe size={13} style={{ marginRight: 5 }} /> Global
          </button>
        </div>
      </div>

      {tab === 'local' && (
        !lastPrediction ? (
          <div className="card glass empty-state">
            <div className="ic"><Crosshair size={26} /></div>
            No prediction selected yet. Run a manual or batch prediction to generate a local SHAP explanation.
            <div style={{ marginTop: 14 }}>
              <button className="btn btn-primary btn-sm" onClick={() => navigate('/manual')}>Make a prediction</button>
            </div>
          </div>
        ) : (
          <>
            <div className="card glass" style={{ marginBottom: 18 }}>
              <div className="flex justify-between items-center" style={{ flexWrap: 'wrap', gap: 10 }}>
                <div>
                  <div className="text-faint" style={{ fontSize: 12 }}>Explaining applicant</div>
                  <div style={{ fontSize: 20, fontWeight: 800 }} className="mono">{lastPrediction.id}</div>
                </div>
                <span className={`badge ${lastPrediction.approved ? 'badge-success' : 'badge-danger'}`} style={{ fontSize: 13 }}>
                  {lastPrediction.prediction} · {lastPrediction.confidence}%
                </span>
              </div>
            </div>

            <div className="section-grid-2" style={{ marginBottom: 18 }}>
              <div className="card glass">
                <div className="card-head"><h3 className="flex items-center gap-sm"><BarChart3 size={17} /> Feature Contributions</h3><span className="sub">SHAP values</span></div>
                <ShapBars contributions={lastPrediction.contributions} max={10} />
              </div>
              <div className="card glass">
                <div className="card-head"><h3 className="flex items-center gap-sm"><GitBranch size={17} /> Waterfall</h3><span className="sub">base → prediction</span></div>
                <ShapWaterfall pred={lastPrediction} max={7} />
              </div>
            </div>

            <div className="section-grid-2">
              <div className="card glass">
                <div className="card-head"><h3 className="flex items-center gap-sm" style={{ color: '#22c55e' }}><TrendingUp size={17} /> Top Positive Drivers</h3></div>
                {lastPrediction.topPositive.length ? lastPrediction.topPositive.map((c) => (
                  <div key={c.key} className="flex justify-between items-center" style={{ padding: '10px 0', borderBottom: '1px solid var(--stroke)' }}>
                    <span>{c.label}</span>
                    <span className="mono" style={{ color: '#4ade80' }}>+{c.contribution.toFixed(3)}</span>
                  </div>
                )) : <div className="text-faint" style={{ fontSize: 13 }}>None</div>}
              </div>
              <div className="card glass">
                <div className="card-head"><h3 className="flex items-center gap-sm" style={{ color: '#ef4444' }}><TrendingDown size={17} /> Top Negative Drivers</h3></div>
                {lastPrediction.topNegative.length ? lastPrediction.topNegative.map((c) => (
                  <div key={c.key} className="flex justify-between items-center" style={{ padding: '10px 0', borderBottom: '1px solid var(--stroke)' }}>
                    <span>{c.label}</span>
                    <span className="mono" style={{ color: '#f87171' }}>{c.contribution.toFixed(3)}</span>
                  </div>
                )) : <div className="text-faint" style={{ fontSize: 13 }}>None</div>}
              </div>
            </div>
          </>
        )
      )}

      {tab === 'global' && (
        <div className="card glass">
          <div className="card-head">
            <h3 className="flex items-center gap-sm"><Globe size={17} /> Global Feature Importance</h3>
            <span className="sub">model-wide impact</span>
          </div>
          <ResponsiveContainer width="100%" height={420}>
            <BarChart data={global} layout="vertical" margin={{ left: 40, right: 30 }}>
              <XAxis type="number" stroke="#6b7a96" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis dataKey="label" type="category" stroke="#aebbd0" fontSize={12} width={140} tickLine={false} axisLine={false} />
              <Tooltip cursor={{ fill: 'rgba(255,255,255,0.04)' }} contentStyle={{ background: '#0b1730', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 12 }} />
              <Bar dataKey="importance" radius={[0, 8, 8, 0]} barSize={20}>
                {global.map((_, i) => (
                  <Cell key={i} fill={`url(#barg)`} />
                ))}
              </Bar>
              <defs>
                <linearGradient id="barg" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#2563eb" />
                  <stop offset="100%" stopColor="#14b8a6" />
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
          <p className="text-dim" style={{ fontSize: 13, marginTop: 8 }}>
            Credit history, repayment capacity (EMI-to-income) and loan-to-income ratio dominate LendIQ's
            decisions — consistent with sound underwriting practice.
          </p>
        </div>
      )}
    </div>
  )
}
