import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Logo from '../components/ui/Logo'
import Particles from '../components/ui/Particles'
import { useAuth } from '../context/AuthContext'

const STEPS = ['Initialising LendIQ', 'Loading XGBoost model', 'Warming SHAP explainer', 'Securing session', 'Ready']

export default function Splash() {
  const [progress, setProgress] = useState(0)
  const [step, setStep] = useState(0)
  const navigate = useNavigate()
  const { user, loading } = useAuth()

  useEffect(() => {
    const id = setInterval(() => {
      setProgress((p) => {
        const next = Math.min(p + 4 + Math.random() * 6, 100)
        setStep(Math.min(STEPS.length - 1, Math.floor((next / 100) * STEPS.length)))
        return next
      })
    }, 110)
    return () => clearInterval(id)
  }, [])

  useEffect(() => {
    if (progress >= 100 && !loading) {
      const id = setTimeout(() => navigate(user ? '/dashboard' : '/login'), 350)
      return () => clearTimeout(id)
    }
  }, [progress, loading, user, navigate])

  return (
    <div className="splash" style={{ position: 'relative', overflow: 'hidden' }}>
      <Particles density={70} />
      <div style={{ position: 'relative', zIndex: 1 }}>
        <div className="coin-scene" style={{ filter: 'drop-shadow(0 16px 40px rgba(37,99,235,0.5))' }}>
          <div className="coin">
            <Logo size={104} />
          </div>
        </div>
        <h1 className="splash-title">
          Lend<span style={{ background: 'linear-gradient(120deg,#5eead4,#93c5fd)', WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>IQ</span>
        </h1>
        <p className="splash-sub">Smarter Lending Decisions Powered by Explainable AI</p>

        <div className="splash-bar">
          <span style={{ width: `${progress}%`, transition: 'width 0.15s ease' }} />
        </div>
        <div style={{ marginTop: 14, fontSize: 13, color: 'var(--text-faint)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9 }}>
          <span className="spinner" style={{ width: 14, height: 14 }} />
          {STEPS[step]}… {Math.round(progress)}%
        </div>

        <div style={{ marginTop: 28, display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
          <span className="feature-chip">⚡ XGBoost · 88.62%</span>
          <span className="feature-chip">🧠 SHAP Explainability</span>
          <span className="feature-chip">🔒 Firebase Secure</span>
        </div>
      </div>
    </div>
  )
}
