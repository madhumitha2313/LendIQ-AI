#!/usr/bin/env bash
# ============================================================
# LendIQ — one-shot setup
# Installs frontend + backend deps, trains the model, and wires
# the frontend to the local FastAPI service.
# ============================================================
set -e
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "▸ Installing root orchestration deps…"
npm install --silent

echo "▸ Installing frontend deps…"
( cd frontend && npm install --silent )

echo "▸ Creating frontend/.env (joins UI → FastAPI)…"
if [ ! -f frontend/.env ]; then
  cat > frontend/.env <<'EOF'
VITE_API_BASE_URL=http://127.0.0.1:8000
VITE_API_KEY=lendiq-dev-key
EOF
  echo "  created frontend/.env"
else
  echo "  frontend/.env already exists — leaving it"
fi

echo "▸ Setting up Python backend…"
cd backend
python3 -m venv .venv
. .venv/bin/activate
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet

echo "▸ Training XGBoost model…"
python train_model.py
cd "$ROOT"

echo ""
echo "✅ Setup complete. Start everything with:  npm run dev"
echo "   • Frontend → http://localhost:5173"
echo "   • API      → http://127.0.0.1:8000  (docs at /docs)"
echo "   • API key  → lendiq-dev-key (set LENDIQ_API_KEY to change)"
