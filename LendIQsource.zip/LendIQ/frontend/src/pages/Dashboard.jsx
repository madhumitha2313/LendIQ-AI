import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Layers, CheckCircle2, XCircle, Percent, CalendarClock, Gauge,
  ArrowRight, Sparkles, TrendingUp, Activity,
} from 'lucide-react'
import {
  ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, Tooltip, XAxis, YAxis,
} from 'recharts'
import StatCard from '../components/ui/StatCard'
import { StaggerGrid, StaggerItem } from '../components/ui/Reveal'
import { usePrediction } from '../context/PredictionContext'
import { useAuth } from '../context/AuthContext'
import { MODEL_INFO } from '../engine/scoringEngine'

function computeStats(history) {
  const total = history.length
  const approved = history.filter((h) => h.approved).length
  const rejected = total - approved
  const today = new Date().toDateString()
  const todays = history.filter((h) => new Date(h.timestamp).toDateString() === today).length
  const avgConf = total ? history.reduce((s, h) => s + (h.confidence || 0), 0) / total : 0
  const rate = total ? (approved / total) * 100 : 0
  return { total, approved, rejected, todays, avgConf, rate }
}

function buildTrend(history) {
  // last 7 days approval counts
  const days = []
  for (let i = 6; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    const key = d.toDateString()
    const label = d.toLocaleDateString(undefined, { weekday: 'short' })
    const onDay = history.filter((h) => new Date(h.timestamp).toDateString() === key)
    days.push({
      day: label,
      approved: onDay.filter((h) => h.approved).length,
      rejected: onDay.filter((h) => !h.approved).length,
    })
  }
  return days
}

export default function Dashboard() {
  const { history } = usePrediction()
  const { user } = useAuth()
  const navigate = useNavigate()

  const stats = useMemo(() => computeStats(history), [history])
  const trend = useMemo(() => buildTrend(history), [history])
  const donut = [
    { name: 'Approved', value: stats.approved, color: '#22c55e' },
    { name: 'Rejected', value: stats.rejected, color: '#ef4444' },
  ]
  const recent = history.slice(0, 6)

  return (
    <div className="page">
      <div className="flex justify-between items-center" style={{ flexWrap: 'wrap', gap: 12, marginBottom: 22 }}>
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-sub">Your lending command center · real-time decision intelligence</p>
        </div>
        <button className="btn btn-primary" onClick={() => navigate('/manual')}>
          <Sparkles size={16} /> New Prediction
        </button>
      </div>

      {/* Welcome / model card */}
      <div className="card glass" style={{ marginBottom: 18, position: 'relative', overflow: 'hidden' }}>
        <div className="glow" style={{ position: 'absolute', right: -40, top: -40, width: 200, height: 200, borderRadius: '50%', background: '#2563eb', filter: 'blur(60px)', opacity: 0.35 }} />
        <div className="flex justify-between items-center" style={{ flexWrap: 'wrap', gap: 18, position: 'relative' }}>
          <div>
            <div className="badge badge-info" style={{ marginBottom: 10 }}><Activity size={13} /> Live</div>
            <h2 style={{ fontSize: 24 }}>Welcome back, {user?.name?.split(' ')[0] || 'Analyst'} 👋</h2>
            <p className="text-dim" style={{ fontSize: 14, marginTop: 4 }}>
              You've processed <strong style={{ color: 'var(--text)' }}>{stats.total}</strong> applications with LendIQ.
            </p>
          </div>
          <div className="flex gap-md" style={{ flexWrap: 'wrap' }}>
            <div className="kpi-pill">
              <div className="l">Active Model</div>
              <div className="v" style={{ fontSize: 16 }}>{MODEL_INFO.name}</div>
            </div>
            <div className="kpi-pill">
              <div className="l">Model Accuracy</div>
              <div className="v" style={{ color: '#5eead4' }}>{MODEL_INFO.accuracy}%</div>
            </div>
            <div className="kpi-pill">
              <div className="l">Features</div>
              <div className="v">{MODEL_INFO.features}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <StaggerGrid className="stat-grid" style={{ marginBottom: 18 }}>
        <StaggerItem><StatCard icon={Layers} label="Total Predictions" value={stats.total} tone="primary" /></StaggerItem>
        <StaggerItem><StatCard icon={CheckCircle2} label="Approved Loans" value={stats.approved} tone="success" /></StaggerItem>
        <StaggerItem><StatCard icon={XCircle} label="Rejected Loans" value={stats.rejected} tone="danger" /></StaggerItem>
        <StaggerItem><StatCard icon={Percent} label="Approval Rate" value={stats.rate} decimals={1} suffix="%" tone="teal" /></StaggerItem>
        <StaggerItem><StatCard icon={CalendarClock} label="Today's Predictions" value={stats.todays} tone="violet" /></StaggerItem>
        <StaggerItem><StatCard icon={Gauge} label="Avg. Confidence" value={stats.avgConf} decimals={1} suffix="%" tone="warning" /></StaggerItem>
      </StaggerGrid>

      {/* Charts */}
      <div className="section-grid-2" style={{ marginBottom: 18 }}>
        <div className="card glass">
          <div className="card-head">
            <h3 className="flex items-center gap-sm"><TrendingUp size={17} /> 7-Day Decision Trend</h3>
            <span className="sub">approved vs rejected</span>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={trend} margin={{ left: -20, right: 6, top: 6 }}>
              <defs>
                <linearGradient id="ga" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22c55e" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gr" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" stroke="#6b7a96" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#6b7a96" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip contentStyle={{ background: '#0b1730', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 12 }} />
              <Area type="monotone" dataKey="approved" stroke="#22c55e" strokeWidth={2.5} fill="url(#ga)" />
              <Area type="monotone" dataKey="rejected" stroke="#ef4444" strokeWidth={2.5} fill="url(#gr)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card glass">
          <div className="card-head">
            <h3>Approval Distribution</h3>
            <span className="sub">all-time</span>
          </div>
          {stats.total === 0 ? (
            <div className="empty-state"><div className="ic"><Activity size={26} /></div>No predictions yet</div>
          ) : (
            <div className="flex items-center" style={{ gap: 10 }}>
              <ResponsiveContainer width="55%" height={220}>
                <PieChart>
                  <Pie data={donut} dataKey="value" innerRadius={58} outerRadius={88} paddingAngle={3} stroke="none">
                    {donut.map((d) => <Cell key={d.name} fill={d.color} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: '#0b1730', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 12 }} />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ flex: 1 }}>
                <div className="flex items-center justify-between" style={{ padding: '10px 0', borderBottom: '1px solid var(--stroke)' }}>
                  <span className="flex items-center gap-sm"><span style={{ width: 10, height: 10, borderRadius: 3, background: '#22c55e' }} /> Approved</span>
                  <strong>{stats.approved}</strong>
                </div>
                <div className="flex items-center justify-between" style={{ padding: '10px 0' }}>
                  <span className="flex items-center gap-sm"><span style={{ width: 10, height: 10, borderRadius: 3, background: '#ef4444' }} /> Rejected</span>
                  <strong>{stats.rejected}</strong>
                </div>
                <div style={{ marginTop: 10, fontSize: 13, color: 'var(--text-dim)' }}>
                  Approval rate <strong style={{ color: '#5eead4' }}>{stats.rate.toFixed(1)}%</strong>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Recent activity */}
      <div className="card glass">
        <div className="card-head">
          <h3 className="flex items-center gap-sm"><Activity size={17} /> Recent Activity</h3>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate('/history')}>View all <ArrowRight size={14} /></button>
        </div>
        {recent.length === 0 ? (
          <div className="empty-state">
            <div className="ic"><Layers size={26} /></div>
            No predictions yet — run your first one to see it here.
            <div style={{ marginTop: 14 }}>
              <button className="btn btn-primary btn-sm" onClick={() => navigate('/manual')}>Make a prediction</button>
            </div>
          </div>
        ) : (
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr><th>Applicant</th><th>Decision</th><th>Confidence</th><th>Risk</th><th>Reason</th><th>When</th></tr>
              </thead>
              <tbody>
                {recent.map((r) => (
                  <tr key={r.id}>
                    <td className="mono">{r.applicantId}</td>
                    <td><span className={`badge ${r.approved ? 'badge-success' : 'badge-danger'}`}>{r.prediction}</span></td>
                    <td>{r.confidence}%</td>
                    <td><span className={`badge ${r.riskLevel === 'LOW' ? 'badge-success' : r.riskLevel === 'MEDIUM' ? 'badge-warn' : 'badge-danger'}`}>{r.riskLevel}</span></td>
                    <td className="text-dim">{r.reason}</td>
                    <td className="text-faint">{new Date(r.timestamp).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
