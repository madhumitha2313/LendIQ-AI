// ============================================================
// Firebase initialisation
// LendIQ works with OR without Firebase. If the environment
// variables below are not provided, `firebaseEnabled` is false
// and the app transparently falls back to local/demo auth and
// localStorage-backed prediction history.
// ============================================================
import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'

const cfg = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
}

export const firebaseEnabled = Boolean(cfg.apiKey && cfg.projectId && cfg.appId)

let auth = null
let db = null

if (firebaseEnabled) {
  try {
    const app = initializeApp(cfg)
    auth = getAuth(app)
    db = getFirestore(app)
  } catch (err) {
    // Never let a misconfigured Firebase break the app — fall back to demo mode.
    console.warn('[LendIQ] Firebase init failed, using demo mode:', err?.message)
  }
}

export { auth, db }
